<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ScheduleController;
use App\Http\Controllers\Api\KonselingController;
use App\Http\Controllers\Api\LaporanController;


Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

// Route API Login
Route::post('/login/siswa', [AuthController::class, 'loginSiswa']);
Route::post('/login/guru', [AuthController::class, 'loginGuru']);
Route::post('/login/admin', [AuthController::class, 'loginAdmin']);
Route::post('/reset-password', [AuthController::class, 'resetPassword']);
Route::post('/update-profile', [AuthController::class, 'updateProfile']);
Route::get('/siswa', [AuthController::class, 'getSiswa']);
Route::post('/siswa', [AuthController::class, 'storeSiswa']);

// Route API Jadwal Guru BK
Route::get('/schedules', [ScheduleController::class, 'index']);

// Route API Konseling
Route::get('/konselings', [KonselingController::class, 'index']);
Route::post('/konselings', [KonselingController::class, 'store']);
Route::patch('/konselings/{id}/status', [KonselingController::class, 'updateStatus']);
Route::delete('/konselings/{id}', [KonselingController::class, 'destroy']);

// Route API Laporan Kasus Siswa
Route::get('/laporan', [LaporanController::class, 'index']);
Route::post('/laporan', [LaporanController::class, 'store']);
Route::patch('/laporan/{id}/status', [LaporanController::class, 'updateStatus']);
Route::delete('/laporan/{id}', [LaporanController::class, 'destroy']);

// Route API Admin
Route::get('/admin/users', [\App\Http\Controllers\Api\AdminController::class, 'getUsers']);
Route::post('/admin/users', [\App\Http\Controllers\Api\AdminController::class, 'storeUser']);
Route::put('/admin/users/{id}', [\App\Http\Controllers\Api\AdminController::class, 'updateUser']);
Route::delete('/admin/users/{id}', [\App\Http\Controllers\Api\AdminController::class, 'deleteUser']);
Route::get('/admin/stats', [\App\Http\Controllers\Api\AdminController::class, 'getStats']);
Route::get('/analytics/advisor', [\App\Http\Controllers\Api\AnalyticsController::class, 'getAdvisorAdvice']);
Route::get('/laporan/{id}/export-pdf', [\App\Http\Controllers\Api\LaporanExportController::class, 'exportPDF']);



use App\Http\Controllers\Api\PushSubscriptionController;
use App\Http\Controllers\Api\ChatController;

Route::post('/push-subscribe', [PushSubscriptionController::class, 'subscribe']);
Route::post('/chats/notify', [PushSubscriptionController::class, 'notify']);

// Routes Chat
Route::get('/chats/unread', [ChatController::class, 'getUnreadCounts']);
Route::get('/chats/stream', [ChatController::class, 'stream']);
Route::get('/chats', [ChatController::class, 'index']);
Route::post('/chats', [ChatController::class, 'store']);
Route::post('/chats/read', [ChatController::class, 'markAsRead']);
