<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class SuratPanggilan extends Model
{
    use HasFactory;

    protected $fillable = [
        'guru_id',
        'siswa_id',
        'nomor_surat',
        'tanggal_panggilan',
        'waktu_panggilan',
        'alasan',
        'status',
    ];

    public function guru()
    {
        return $this->belongsTo(User::class, 'guru_id');
    }

    public function siswa()
    {
        return $this->belongsTo(User::class, 'siswa_id');
    }
}
