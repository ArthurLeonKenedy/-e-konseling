<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ScheduleController extends Controller
{
    public function index()
    {
        $schedules = DB::table('schedules')
            ->join('users', 'schedules.guru_id', '=', 'users.id')
            ->select('schedules.*', 'users.name as guru_name')
            ->get();

        return response()->json([
            'success' => true,
            'data' => $schedules
        ]);
    }
}
