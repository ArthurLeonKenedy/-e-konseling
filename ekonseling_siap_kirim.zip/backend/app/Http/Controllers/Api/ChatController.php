<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Message;
use Illuminate\Http\Request;
use App\Notifications\NewChatNotification;

class ChatController extends Controller
{
    // Ambil riwayat chat antara dua user
    public function index(Request $request)
    {
        $sender_id = $request->sender_id;
        $receiver_id = $request->receiver_id;

        $messages = Message::where(function($q) use ($sender_id, $receiver_id) {
            $q->where(function($q2) use ($sender_id, $receiver_id) {
                $q2->where('sender_id', $sender_id)->where('receiver_id', $receiver_id);
            })->orWhere(function($q2) use ($sender_id, $receiver_id) {
                $q2->where('sender_id', $receiver_id)->where('receiver_id', $sender_id);
            });
        })
        ->orderBy('created_at', 'asc')
        ->get();

        return response()->json([
            'success' => true,
            'data'    => $messages
        ]);
    }

    // Simpan pesan baru
    public function store(Request $request)
    {
        $request->validate([
            'sender_id'   => 'required|exists:users,id',
            'receiver_id' => 'required|exists:users,id',
            'message'     => 'required|string',
        ]);

        $message = Message::create([
            'sender_id'   => $request->sender_id,
            'receiver_id' => $request->receiver_id,
            'message'     => $request->message,
            'is_read'     => false,
        ]);

        // Kirim Notifikasi Push via internal controller call atau broadcast
        try {
            $sender = \App\Models\User::find($request->sender_id);
            $receiver = \App\Models\User::find($request->receiver_id);
            if ($receiver) {
                $receiver->notify(new NewChatNotification([
                    'senderName' => $sender->name,
                    'senderId' => $sender->id,
                    'senderRole' => $sender->role,
                    'text' => $request->message
                ]));
            }
        } catch (\Throwable $e) {
            // Silently fail notification but keep message saved
            \Illuminate\Support\Facades\Log::error('Push Notification Error: ' . $e->getMessage());
        }

        return response()->json([
            'success' => true,
            'data'    => $message
        ]);
    }

    // Mark as read
    public function markAsRead(Request $request)
    {
        $query = Message::where('receiver_id', $request->receiver_id)
                       ->where('is_read', false);
        
        if ($request->has('sender_id')) {
            $query->where('sender_id', $request->sender_id);
        }

        $query->update(['is_read' => true]);

        return response()->json(['success' => true]);
    }

    // Ambil jumlah chat belum terbaca untuk dashboard
    public function getUnreadCounts(Request $request)
    {
        $receiver_id = $request->receiver_id;
        
        if (!$receiver_id) {
            return response()->json(['success' => false, 'message' => 'receiver_id required'], 422);
        }

        $counts = Message::where('receiver_id', $receiver_id)
            ->where('is_read', false)
            ->selectRaw('sender_id, count(*) as total')
            ->groupBy('sender_id')
            ->get();

        return response()->json([
            'success' => true,
            'data'    => $counts
        ]);
    }

    // Stream pesan baru menggunakan SSE (Server-Sent Events)
    // Hanya mengirimkan pesan BARU setelah koneksi dibuka (bukan history)
    public function stream(Request $request)
    {
        $sender_id = $request->sender_id;
        $receiver_id = $request->receiver_id;

        // Penting: Tutup session agar tidak me-lock thread PHP lain (jika menggunakan session)
        if (session_id()) session_write_close();
        
        // Hilangkan limit waktu eksekusi PHP
        set_time_limit(0);

        return response()->stream(function () use ($sender_id, $receiver_id) {
            // Mulai dari ID terbesar yang sudah ada
            $lastId = Message::where(function($q) use ($sender_id, $receiver_id) {
                    $q->where(function($q2) use ($sender_id, $receiver_id) {
                        $q2->where('sender_id', $sender_id)->where('receiver_id', $receiver_id);
                    })->orWhere(function($q2) use ($sender_id, $receiver_id) {
                        $q2->where('sender_id', $receiver_id)->where('receiver_id', $sender_id);
                    });
                })->max('id') ?? 0;
            
            $startTime = time();
            $maxDuration = 300; // Putus paksa setiap 5 menit agar frontend auto-reconnect ringan (mencegah zombie process)

            // Loop selamanya sampai koneksi diputus browser
            while (true) {
                if (connection_aborted() || (time() - $startTime) > $maxDuration) {
                    break;
                }

                // Cari pesan baru
                $newMessages = Message::where(function($q) use ($sender_id, $receiver_id) {
                    $q->where(function($q2) use ($sender_id, $receiver_id) {
                        $q2->where('sender_id', $sender_id)->where('receiver_id', $receiver_id);
                    })->orWhere(function($q2) use ($sender_id, $receiver_id) {
                        $q2->where('sender_id', $receiver_id)->where('receiver_id', $sender_id);
                    });
                })
                ->where('id', '>', $lastId)
                ->orderBy('created_at', 'asc')
                ->get();

                if ($newMessages->count() > 0) {
                    foreach ($newMessages as $msg) {
                        echo "data: " . json_encode($msg) . "\n\n";
                        $lastId = $msg->id;
                    }
                } else {
                    // Kirim heartbeat agar koneksi tidak timeout oleh proxy/browser
                    echo ": heartbeat\n\n";
                }

                @ob_flush();
                @flush();

                // Tunggu sebentar sebelum cek lagi (1 detik untuk responsivitas lebih baik)
                sleep(1);
            }
        }, 200, [
            'Content-Type' => 'text/event-stream',
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Pragma' => 'no-cache',
            'Expires' => '0',
            'Connection' => 'keep-alive',
            'X-Accel-Buffering' => 'no',
        ]);
    }
}
