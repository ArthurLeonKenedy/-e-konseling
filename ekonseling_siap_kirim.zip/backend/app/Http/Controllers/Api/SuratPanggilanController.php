<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\SuratPanggilan;

class SuratPanggilanController extends Controller
{
    public function index(Request $request)
    {
        $query = SuratPanggilan::with(['siswa:id,name,kelas', 'guru:id,name']);

        if ($request->has('guru_id')) {
            $query->where('guru_id', $request->guru_id);
        }

        if ($request->has('siswa_id')) {
            $query->where('siswa_id', $request->siswa_id);
        }

        $surat = $query->orderBy('created_at', 'desc')->get();
        return response()->json($surat);
    }

    public function store(Request $request)
    {
        $request->validate([
            'guru_id' => 'required|exists:users,id',
            'siswa_id' => 'required|exists:users,id',
            'tanggal_panggilan' => 'required|date',
            'waktu_panggilan' => 'required',
            'alasan' => 'required|string',
        ]);

        $nomor_surat = 'SP/' . date('Y/m') . '/' . strtoupper(substr(uniqid(), -5));

        $surat = SuratPanggilan::create([
            'guru_id' => $request->guru_id,
            'siswa_id' => $request->siswa_id,
            'nomor_surat' => $nomor_surat,
            'tanggal_panggilan' => $request->tanggal_panggilan,
            'waktu_panggilan' => $request->waktu_panggilan,
            'alasan' => $request->alasan,
            'status' => 'Menunggu',
        ]);

        return response()->json($surat, 201);
    }

    public function show(string $id)
    {
        $surat = SuratPanggilan::with(['guru:id,name', 'siswa:id,name,kelas'])->findOrFail($id);
        return response()->json($surat);
    }

    public function update(Request $request, string $id)
    {
        $surat = SuratPanggilan::findOrFail($id);
        
        $request->validate([
            'status' => 'required|in:Menunggu,Selesai,Batal'
        ]);

        $surat->update(['status' => $request->status]);

        return response()->json($surat);
    }

    public function destroy(string $id)
    {
        $surat = SuratPanggilan::findOrFail($id);
        $surat->delete();

        return response()->json(['message' => 'Surat Panggilan deleted']);
    }
}
