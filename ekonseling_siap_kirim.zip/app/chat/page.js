"use client";
import { useState, useEffect, useRef, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Link from "next/link";
import NotificationBanner from "../components/NotificationBanner";

import { ChatSSE } from "../../lib/chatSSE";

function ChatContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const targetId = searchParams.get("targetId");
  const targetName = searchParams.get("targetName");
  const targetRole = searchParams.get("targetRole");

  const [currentUserId, setCurrentUserId] = useState(null);
  const [currentUserRole, setCurrentUserRole] = useState("siswa");
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState("connecting");
  const messagesEndRef = useRef(null);
  const chatSSERef = useRef(null);

  useEffect(() => {
    const userStr = localStorage.getItem("user");
    if (!userStr) return;
    const user = JSON.parse(userStr);
    setCurrentUserId(user.id);
    setCurrentUserRole(user.role || "siswa");
  }, []);

  const setupSSE = (userId, receiverId) => {
    if (chatSSERef.current) {
      chatSSERef.current.disconnect();
    }

    const sse = new ChatSSE(
      `http://localhost:8000/api/chats/stream?sender_id=${userId}&receiver_id=${receiverId}`,
      {
        onMessage: (newMessage) => {
          setMessages((prev) => {
            if (prev.some((m) => m.id === newMessage.id)) return prev;

            if (newMessage.receiver_id == userId && !newMessage.is_read) {
              fetch("http://localhost:8000/api/chats/read", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ sender_id: receiverId, receiver_id: userId }),
              }).catch(() => {});
            }

            return [...prev, newMessage];
          });
        },
        onStatusChange: (status) => {
          setConnectionStatus(status);
        }
      }
    );

    chatSSERef.current = sse;
    sse.connect();
  };

  useEffect(() => {
    if (!targetId || !targetName || !currentUserId) return;

    const loadInitialMessages = async () => {
      try {
        const response = await fetch(
          `http://localhost:8000/api/chats?sender_id=${currentUserId}&receiver_id=${targetId}`
        );
        const data = await response.json();
        if (data.success) {
          setMessages(data.data);
        }
      } catch (error) {
        console.error("Failed to load initial messages:", error);
      }
    };
    loadInitialMessages();

    setupSSE(currentUserId, targetId);

    return () => {
      if (chatSSERef.current) {
        chatSSERef.current.disconnect();
        chatSSERef.current = null;
      }
    };
  }, [currentUserId, targetId, targetName]);

  useEffect(() => {
    if (!targetId || !targetName) {
      router.push(currentUserRole === "guru" ? "/guru" : "/siswa");
    }
  }, [targetId, targetName, router, currentUserRole]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim() || !currentUserId || isSending) return;

    const tempInput = input.trim();
    setInput("");
    setIsSending(true);

    try {
      const response = await fetch("http://localhost:8000/api/chats", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sender_id: currentUserId,
          receiver_id: targetId,
          message: tempInput,
        }),
      });
      const data = await response.json();
      if (data.success) {
        setMessages((prev) => {
          if (prev.some((m) => m.id === data.data.id)) return prev;
          return [...prev, data.data];
        });
      } else {
        setInput(tempInput);
      }
    } catch (error) {
      console.error("Failed to send message:", error);
      setInput(tempInput);
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(e);
    }
  };

  return (
    <div className="min-h-screen mesh-bg flex flex-col font-sans">
      <header className="bg-emerald-800 text-white p-5 shadow-lg flex justify-between items-center z-20 border-b border-emerald-900/20">
        <div className="flex items-center gap-4">
          <Link
            href={currentUserRole === "guru" ? "/guru" : "/siswa"}
            className="p-2 bg-emerald-900 border border-emerald-700 hover:bg-rose-700 rounded text-[10px] font-bold transition-all"
          >
            KEMBALI
          </Link>
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-white text-emerald-800 font-extrabold rounded-full flex items-center justify-center p-1 border-2 border-white shadow">
              {targetName?.charAt(0)}
            </div>
            <div>
              <h1 className="text-sm md:text-base font-bold tracking-tight leading-tight uppercase">
                {targetName}
              </h1>
              <p className="text-[10px] text-emerald-200 font-bold tracking-widest">
                {targetRole?.toUpperCase()} PEMBIMBING
              </p>
            </div>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2">
          {connectionStatus === 'connected' && <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>}
          {connectionStatus === 'reconnecting' && <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>}
          {connectionStatus === 'connecting' && <span className="w-2 h-2 rounded-full bg-slate-400 animate-bounce"></span>}
          {connectionStatus === 'failed' && <span className="w-2 h-2 rounded-full bg-rose-500"></span>}
          <div className="text-[10px] font-bold text-emerald-200 uppercase tracking-widest border border-emerald-700 px-3 py-1 rounded">
            {connectionStatus === 'connected' ? 'Sinkronisasi Aktif' : 
             connectionStatus === 'reconnecting' ? 'Menyambung Ulang...' : 
             connectionStatus === 'failed' ? 'Koneksi Terputus' : 'Memulai Koneksi...'}
          </div>
        </div>
      </header>

      <div className="max-w-4xl w-full mx-auto px-4 pt-4">
        <NotificationBanner />
      </div>

      <main className="flex-1 max-w-4xl w-full mx-auto p-4 md:p-8 overflow-y-auto flex flex-col gap-4">
        {messages.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
            <div className="p-8 bg-white border border-slate-300 rounded shadow-sm text-center">
              <p className="text-sm font-bold text-slate-700 uppercase mb-1">Mulai Diskusi Baru</p>
              <p className="text-[10px] font-medium text-slate-400">
                Kirimkan pesan Anda untuk memulai konsultasi resmi.
              </p>
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = msg.sender_id == currentUserId;
            const time = new Date(msg.created_at).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            });
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isMe ? "items-end" : "items-start"} max-w-[85%] md:max-w-[70%] ${isMe ? "self-end" : "self-start"}`}
              >
                <div
                  className={`px-5 py-3 rounded text-sm md:text-base leading-relaxed border shadow-sm ${
                    isMe
                      ? "bg-emerald-100 text-emerald-900 border-emerald-200 rounded-br-none"
                      : "bg-white text-slate-800 border-slate-200 rounded-bl-none"
                  }`}
                >
                  {msg.message}
                </div>
                <span className="text-[10px] font-bold text-slate-400 uppercase mt-1 px-1 tracking-tight">
                  {time} {isMe && msg.is_read && <span className="text-emerald-500 ml-1">✓✓</span>}
                </span>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </main>

      <footer className="bg-slate-200 border-t border-slate-300 p-4 md:p-6 sticky bottom-0 z-20">
        <form onSubmit={sendMessage} className="max-w-4xl mx-auto flex gap-4">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ketik isi pesan Anda di sini... (Enter untuk kirim)"
            disabled={isSending || !currentUserId}
            className="flex-1 px-4 py-3 bg-white border border-slate-300 rounded text-slate-800 placeholder-slate-400 outline-none focus:border-emerald-800 font-medium disabled:opacity-60"
          />
          <button
            type="submit"
            disabled={!input.trim() || isSending || !currentUserId}
            className="bg-emerald-800 hover:bg-emerald-900 disabled:bg-slate-400 text-white px-8 rounded font-bold transition-all shadow-md active:scale-95 text-[10px] uppercase tracking-widest"
          >
            {isSending ? "MENGIRIM..." : "KIRIM PESAN"}
          </button>
        </form>
      </footer>
    </div>
  );
}

export default function ChatPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-slate-100 flex items-center justify-center font-bold">
          MEMBUKA SESI...
        </div>
      }
    >
      <ChatContent />
    </Suspense>
  );
}
