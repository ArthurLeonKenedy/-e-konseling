"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    total_siswa: 0,
    total_guru: 0,
    total_admin: 0,
    total_kasus: 0
  });
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      router.push('/');
      return;
    }
    const parsedUser = JSON.parse(storedUser);
    if (parsedUser.role !== 'admin') {
      router.push('/');
      return;
    }
    setUser(parsedUser);
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch("http://localhost:8000/api/admin/stats");
      const data = await response.json();
      if (data.success) {
        setStats(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch stats", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    router.push('/');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-slate-800"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex mesh-bg font-sans">
      {/* Sidebar */}
      <aside className="w-72 bg-[#052e16] border-r border-emerald-900/20 hidden lg:flex flex-col sticky top-0 h-screen shadow-2xl">
        <div className="p-8 border-b border-white/5 bg-black/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-600 to-emerald-800 flex items-center justify-center p-0.5 shadow-sm shadow-emerald-100">
              <div className="w-full h-full bg-white rounded-lg flex items-center justify-center p-0.5">
                <img src="/logo-smkn1.jpg" alt="Logo" className="w-full h-full object-contain rounded-md" />
              </div>
            </div>
            <div>
              <h1 className="text-sm font-bold text-white tracking-tight leading-tight">E-Konseling</h1>
              <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest">Admin Panel</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-6 space-y-2">
          <a href="/admin" className="flex items-center gap-3 px-4 py-3 rounded-xl bg-emerald-600 text-white font-bold text-sm shadow-lg shadow-emerald-100 transition-all">
            <svg className="w-5 h-5 text-emerald-100/70" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>
            Ringkasan
          </a>
          <a href="/admin/users?role=guru" className="flex items-center gap-3 px-4 py-3 rounded-xl text-emerald-100/60 hover:bg-white/5 hover:text-white font-bold text-sm transition-all">
            <svg className="w-5 h-5 text-emerald-500/50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
            Kelola Guru BK
          </a>
          <a href="/admin/users?role=siswa" className="flex items-center gap-3 px-4 py-3 rounded-xl text-emerald-100/60 hover:bg-white/5 hover:text-white font-bold text-sm transition-all">
            <svg className="w-5 h-5 text-emerald-500/50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l9-5-9-5-9 5 9 5z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" /></svg>
            Kelola Siswa
          </a>
          <a href="/admin/reports" className="flex items-center gap-3 px-4 py-3 rounded-xl text-emerald-100/60 hover:bg-white/5 hover:text-white font-bold text-sm transition-all">
            <svg className="w-5 h-5 text-emerald-500/50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            Laporan Kasus
          </a>
        </nav>

        <div className="p-6 border-t border-white/5">
          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-rose-400 hover:bg-rose-500/10 font-bold text-sm transition-all">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
            Keluar
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-6 lg:p-12 overflow-y-auto">
        <header className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-12">
          <div>
            <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">Ringkasan Sistem</h1>
            <p className="text-slate-500 font-medium mt-1">Pantau performa dan data layanan E-Konseling</p>
          </div>
          <div className="flex items-center gap-4">
             <div className="text-right">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">Administrator</p>
                <p className="text-sm font-bold text-slate-900">{user?.name}</p>
             </div>
             <div className="w-12 h-12 rounded-2xl bg-slate-200 flex items-center justify-center border-4 border-white shadow-sm overflow-hidden">
                <img src="/placeholder-avatar.png" alt="Admin" className="w-full h-full object-cover" />
             </div>
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-12">
          <div className="premium-card p-8 group hover:!bg-emerald-900 transition-all duration-500 border-none shadow-xl shadow-emerald-200/50">
            <div className="w-14 h-14 rounded-2xl bg-indigo-50 group-hover:bg-indigo-400/20 flex items-center justify-center mb-6 transition-colors">
              <svg className="w-7 h-7 text-indigo-600 group-hover:text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
            </div>
            <p className="text-slate-400 group-hover:text-emerald-100 font-bold text-[10px] uppercase tracking-[0.2em]">Total Siswa</p>
            <h4 className="text-4xl font-extrabold text-slate-900 group-hover:text-white mt-2 tabular-nums">{stats.total_siswa}</h4>
          </div>

          <div className="premium-card p-8 group hover:!bg-emerald-800 transition-all duration-500 border-none shadow-xl shadow-emerald-200/50">
            <div className="w-14 h-14 rounded-2xl bg-emerald-50 group-hover:bg-emerald-400/20 flex items-center justify-center mb-6 transition-colors">
              <svg className="w-7 h-7 text-emerald-600 group-hover:text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
            </div>
            <p className="text-slate-400 group-hover:text-emerald-100 font-bold text-[10px] uppercase tracking-[0.2em]">Guru BK</p>
            <h4 className="text-4xl font-extrabold text-slate-900 group-hover:text-white mt-2 tabular-nums">{stats.total_guru}</h4>
          </div>

          <div className="premium-card p-8 group hover:!bg-emerald-700 transition-all duration-500 border-none shadow-xl shadow-emerald-200/50">
            <div className="w-14 h-14 rounded-2xl bg-amber-50 group-hover:bg-amber-400/20 flex items-center justify-center mb-6 transition-colors">
              <svg className="w-7 h-7 text-amber-600 group-hover:text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </div>
            <p className="text-slate-400 group-hover:text-emerald-100 font-bold text-[10px] uppercase tracking-[0.2em]">Kasus Tercatat</p>
            <h4 className="text-4xl font-extrabold text-slate-900 group-hover:text-white mt-2 tabular-nums">{stats.total_kasus}</h4>
          </div>

          <div className="premium-card p-8 group hover:!bg-emerald-600 transition-all duration-500 border-none shadow-xl shadow-emerald-200/50">
            <div className="w-14 h-14 rounded-2xl bg-slate-50 group-hover:bg-slate-400/20 flex items-center justify-center mb-6 transition-colors">
              <svg className="w-7 h-7 text-slate-600 group-hover:text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A10.003 10.003 0 0012 21a9.994 9.994 0 008.21-4.429m-8.387-5.482c-.311.163-.567.455-.733.811m4.83 7.9c.163-.311.455-.567.811-.733a4 4 0 011.192-.412C19.18 18.04 20 16.634 20 15V9a8 8 0 00-8-8c-4.418 0-8 3.582-8 8v6c0 1.634.82 3.04 2.03 3.937 1.144.846 2.03 2.103 2.03 3.563v.5" /></svg>
            </div>
            <p className="text-slate-400 group-hover:text-emerald-100 font-bold text-[10px] uppercase tracking-[0.2em]">Admin Aktif</p>
            <h4 className="text-4xl font-extrabold text-slate-900 group-hover:text-white mt-2 tabular-nums">{stats.total_admin}</h4>
          </div>
        </div>

        {/* Quick Actions */}
        <h3 className="text-xl font-bold text-slate-900 mb-6">Aksi Cepat</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="premium-card p-6 border-l-4 border-l-emerald-600">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="text-lg font-bold text-slate-900">Manajemen Guru BK</h4>
                <p className="text-slate-500 text-sm mt-1">Tambah atau kelola akun guru pembimbing.</p>
                <button 
                  onClick={() => router.push('/admin/users?role=guru')}
                  className="mt-4 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-emerald-100"
                >
                  Buka Menu Guru
                </button>
              </div>
              <div className="w-16 h-16 bg-emerald-50 rounded-2xl flex items-center justify-center">
                 <svg className="w-8 h-8 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
              </div>
            </div>
          </div>

          <div className="premium-card p-6 border-l-4 border-l-indigo-600">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="text-lg font-bold text-slate-900">Manajemen Siswa</h4>
                <p className="text-slate-500 text-sm mt-1">Kelola data siswa dan riwayat bimbingan.</p>
                <button 
                  onClick={() => router.push('/admin/users?role=siswa')}
                  className="mt-4 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-100"
                >
                  Buka Menu Siswa
                </button>
              </div>
              <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center">
                 <svg className="w-8 h-8 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
