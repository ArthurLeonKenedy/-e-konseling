"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function LoginPage() {
  const [role, setRole] = useState(null);
  const [nama, setNama] = useState("");
  const [kelas, setKelas] = useState("");
  const [password, setPassword] = useState("");
  const [nisn, setNisn] = useState("");
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [mounted, setMounted] = useState(false);
  const router = useRouter();

  useEffect(() => { setMounted(true); }, []);

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (isForgotPassword) {
      try {
        const response = await fetch("http://localhost:8000/api/reset-password", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ role: role, name: nama, kelas: kelas, nisn: nisn, new_password: password }),
        });
        const data = await response.json();
        if (data.success) {
          alert(data.message);
          setIsForgotPassword(false);
          setPassword(""); setNisn("");
        } else {
          alert(data.message || "Gagal mengatur ulang kata sandi.");
        }
      } catch (error) {
        alert("Terjadi kesalahan koneksi.");
      } finally {
        setIsLoading(false);
      }
      return;
    }

    const endpoint = role === "siswa" ? "login/siswa" : role === "guru" ? "login/guru" : "login/admin";
    const payload = { name: nama, password: password, ...(role === "siswa" && { kelas: kelas }) };

    try {
      const response = await fetch(`http://localhost:8000/api/${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await response.json();
      if (data.success) {
        localStorage.setItem('user', JSON.stringify(data.user));
        let redirectUrl = "";
        if (role === "siswa") {
          redirectUrl = `/siswa?nama=${encodeURIComponent(data.user.name)}&kelas=${encodeURIComponent(data.user.kelas)}`;
        } else if (role === "guru") {
          redirectUrl = `/guru?nama=${encodeURIComponent(data.user.name)}`;
        } else {
          redirectUrl = "/admin";
        }
        router.push(redirectUrl);
      } else {
        alert(data.message || "Login gagal. Periksa kembali nama dan kata sandi Anda.");
      }
    } catch (error) {
      alert("Gagal terhubung ke server.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col font-sans mesh-bg">
      
      {/* Premium Header */}
      <header className="bg-white/70 backdrop-blur-md border-b border-slate-200/60 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4 animate-fadeInDown">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-800 shadow-lg shadow-emerald-200 flex items-center justify-center p-0.5">
              <div className="w-full h-full bg-white rounded-xl flex items-center justify-center p-1">
                <img src="/logo-smkn1.jpg" alt="Logo" className="w-full h-full object-contain rounded-lg" />
              </div>
            </div>
            <div>
              <h1 className="text-lg font-bold text-slate-900 tracking-tight leading-tight">E-Konseling</h1>
              <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-[0.2em]">SMK Negeri 1 Pontianak</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-8">
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Waktu Lokal</span>
              <span className="text-xs font-bold text-slate-700">{new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB</span>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-6 sm:p-12 relative overflow-hidden">
        {/* Background Accents */}
        <div className="absolute top-1/4 -left-20 w-80 h-80 bg-emerald-100/50 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-1/4 -right-20 w-80 h-80 bg-amber-100/30 rounded-full blur-[100px] animate-pulse delay-1000" />

        <div className="w-full max-w-[1000px] grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
          
          {/* Left Side: Branding/Value Prop */}
          <div className="hidden lg:flex flex-col gap-8 animate-fadeIn">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-700 text-[10px] font-bold uppercase tracking-wider">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                Layanan Konseling Digital Resmi
              </div>
              <h2 className="text-4xl xl:text-5xl font-extrabold text-slate-900 leading-[1.1] tracking-tight">
                Membangun Karakter <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-emerald-800">Masa Depan Bangsa.</span>
              </h2>
              <p className="text-slate-500 text-lg leading-relaxed max-w-md">
                Selamat datang di platform Bimbingan Konseling SMK Negeri 1 Pontianak. Kami siap mendampingi perjalanan akademik dan pribadi Anda.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="group premium-card p-6 !bg-emerald-700 !border-none shadow-xl shadow-emerald-200/50">
                <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" /></svg>
                </div>
                <h4 className="text-white font-extrabold text-base tracking-tight">Konsultasi Real-time</h4>
                <p className="text-emerald-50/80 text-[11px] font-bold mt-2 leading-relaxed">Hubungi guru pembimbing secara langsung melalui sistem chat resmi.</p>
              </div>
              <div className="group premium-card p-6 bg-white shadow-xl shadow-slate-200/50">
                <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>
                </div>
                <h4 className="text-slate-900 font-extrabold text-base tracking-tight">Aman & Rahasia</h4>
                <p className="text-slate-500 text-[11px] font-bold mt-2 leading-relaxed">Seluruh data konsultasi dijaga kerahasiaannya dengan enkripsi sistem.</p>
              </div>
            </div>
          </div>

          {/* Right Side: Login Card */}
          <div className="animate-scaleIn">
            <div className="premium-card overflow-hidden">
              <div className="p-8 sm:p-10">
                <div className="mb-8">
                  <h3 className="text-2xl font-bold text-slate-900">{isForgotPassword ? 'Reset Akun' : 'Selamat Datang'}</h3>
                  <p className="text-slate-500 text-sm mt-1">
                    {isForgotPassword ? 'Verifikasi identitas untuk mengatur ulang sandi' : 'Silakan masuk ke akun Anda'}
                  </p>
                </div>

                {!role ? (
                  <div className="space-y-4">
                    <button
                      id="btn-login-siswa"
                      onClick={() => setRole("siswa")}
                      className="w-full group relative flex items-center justify-between p-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 transition-all duration-300 shadow-lg shadow-emerald-100"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l9-5-9-5-9 5 9 5z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" /></svg>
                        </div>
                        <div className="text-left">
                          <p className="text-white font-bold text-sm">Masuk sebagai Siswa</p>
                          <p className="text-emerald-100/70 text-[10px] uppercase tracking-wider">Akses sistem bimbingan</p>
                        </div>
                      </div>
                      <svg className="w-5 h-5 text-white/50 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
                    </button>

                    <button
                      id="btn-login-guru"
                      onClick={() => setRole("guru")}
                      className="w-full group relative flex items-center justify-between p-4 rounded-2xl bg-white border border-slate-200 hover:border-emerald-200 hover:bg-emerald-50 transition-all duration-300 shadow-sm"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-slate-50 group-hover:bg-emerald-100 flex items-center justify-center group-hover:scale-110 transition-transform">
                          <svg className="w-6 h-6 text-slate-400 group-hover:text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                        </div>
                        <div className="text-left">
                          <p className="text-slate-800 font-bold text-sm">Portal Guru BK</p>
                          <p className="text-slate-400 text-[10px] uppercase tracking-wider group-hover:text-emerald-600/70">Manajemen Layanan</p>
                        </div>
                      </div>
                      <svg className="w-5 h-5 text-slate-300 group-hover:text-emerald-600 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
                    </button>

                    <button
                      id="btn-login-admin"
                      onClick={() => setRole("admin")}
                      className="w-full group relative flex items-center justify-between p-4 rounded-2xl bg-slate-800 hover:bg-slate-900 transition-all duration-300 shadow-sm"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-slate-700 flex items-center justify-center group-hover:scale-110 transition-transform">
                          <svg className="w-6 h-6 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09A10.003 10.003 0 0012 21a9.994 9.994 0 008.21-4.429m-8.387-5.482c-.311.163-.567.455-.733.811m4.83 7.9c.163-.311.455-.567.811-.733a4 4 0 011.192-.412C19.18 18.04 20 16.634 20 15V9a8 8 0 00-8-8c-4.418 0-8 3.582-8 8v6c0 1.634.82 3.04 2.03 3.937 1.144.846 2.03 2.103 2.03 3.563v.5" /></svg>
                        </div>
                        <div className="text-left">
                          <p className="text-white font-bold text-sm">Dashboard Admin</p>
                          <p className="text-slate-400 text-[10px] uppercase tracking-wider">Kontrol Sistem</p>
                        </div>
                      </div>
                      <svg className="w-5 h-5 text-slate-500 group-hover:text-white group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" /></svg>
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleLogin} className="space-y-5">
                    <div className="flex items-center justify-between mb-4">
                      <button
                        type="button"
                        onClick={() => { if (isForgotPassword) setIsForgotPassword(false); else setRole(null); }}
                        className="flex items-center gap-2 text-xs font-bold text-emerald-600 hover:text-emerald-700 transition-colors"
                      >
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 19l-7-7 7-7" /></svg>
                        Kembali
                      </button>
                      <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold uppercase tracking-wider border border-emerald-100">
                        Akses {role}
                      </span>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 uppercase tracking-wide ml-1">Nama Lengkap</label>
                        <input
                          type="text"
                          required
                          value={nama}
                          onChange={(e) => setNama(e.target.value)}
                          placeholder="Ketik nama lengkap..."
                          className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all outline-none text-sm"
                          id="input-nama"
                        />
                      </div>

                      {role === "siswa" && (
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-slate-700 uppercase tracking-wide ml-1">Kelas</label>
                          <input
                            type="text"
                            required
                            value={kelas}
                            onChange={(e) => setKelas(e.target.value)}
                            placeholder="Contoh: XII TKJ 2"
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all outline-none text-sm"
                            id="input-kelas"
                          />
                        </div>
                      )}

                      {isForgotPassword && role === "siswa" && (
                        <div className="space-y-1.5">
                          <label className="text-xs font-bold text-emerald-600 uppercase tracking-wide ml-1">NISN Verifikasi</label>
                          <input
                            type="text"
                            required
                            value={nisn}
                            onChange={(e) => setNisn(e.target.value)}
                            placeholder="10 digit NISN"
                            className="w-full px-4 py-3 rounded-xl border-2 border-emerald-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all outline-none text-sm"
                            id="input-nisn"
                          />
                        </div>
                      )}

                      <div className="space-y-1.5">
                        <label className="text-xs font-bold text-slate-700 uppercase tracking-wide ml-1">
                          {isForgotPassword ? "Sandi Baru" : "Kata Sandi"}
                        </label>
                        <div className="relative">
                          <input
                            type={showPassword ? "text" : "password"}
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="••••••••"
                            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 transition-all outline-none text-sm"
                            id="input-password"
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-emerald-600 transition-colors"
                          >
                            {showPassword ? (
                              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.888 9.888L15 15m3.228-3.228A10.05 10.05 0 0121 12c-1.275 4.057-5.065 7-9.542 7-1.397 0-2.733-.28-3.938-.783" /></svg>
                            ) : (
                              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>

                    {!isForgotPassword && (
                      <div className="flex justify-end">
                        <button
                          type="button"
                          onClick={() => setIsForgotPassword(true)}
                          className="text-xs font-bold text-slate-400 hover:text-emerald-600 transition-colors"
                        >
                          Lupa kata sandi?
                        </button>
                      </div>
                    )}

                    <button
                      id="btn-submit-login"
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-lg shadow-emerald-100 transition-all active:scale-[0.98] disabled:opacity-70 disabled:cursor-not-allowed group relative overflow-hidden"
                    >
                      <span className="relative z-10 flex items-center justify-center gap-2">
                        {isLoading ? (
                          <svg className="w-5 h-5 animate-spin" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" /></svg>
                        ) : isForgotPassword ? 'Simpan Sandi Baru' : 'Masuk ke Portal'}
                      </span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="max-w-7xl mx-auto w-full px-6 py-8 border-t border-slate-200/60 mt-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-loose text-center md:text-left">
            &copy; {new Date().getFullYear()} SMK Negeri 1 Pontianak &bull; BK Digital System v2.0
          </p>
          <div className="flex items-center gap-6">
            <span className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest">Profesional</span>
            <span className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest">Ethis</span>
            <span className="text-[10px] font-bold text-emerald-600/60 uppercase tracking-widest">Responsif</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
