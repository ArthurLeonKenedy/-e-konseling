"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export function useAuthGuard(requiredRole) {
  const router = useRouter();
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  useEffect(() => {
    try {
      const userStr = localStorage.getItem("user");
      if (!userStr) {
        router.replace("/");
        return;
      }
      const user = JSON.parse(userStr);
      
      // Siswa memiliki atribut 'kelas', Guru tidak
      if (requiredRole === "siswa" && !user.kelas) {
        router.replace("/");
        return;
      }
      
      if (requiredRole === "guru" && user.kelas) {
        router.replace("/");
        return;
      }
      
      setIsAuthorized(true);
    } catch {
      localStorage.removeItem("user");
      router.replace("/");
    } finally {
      setIsChecking(false);
    }
  }, [router, requiredRole]);

  return { isAuthorized, isChecking };
}
