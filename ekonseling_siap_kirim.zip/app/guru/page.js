"use client";
import Link from "next/link";
import { Suspense, useState, useEffect, useMemo } from "react";
import { useSearchParams } from "next/navigation";
import { useAuthGuard } from "../hooks/useAuthGuard";
import { 
  AreaChart, Area
} from 'recharts';
import NotificationBanner from "../components/NotificationBanner";

function UpdateStatusForm({ laporan, onSave, onCancel }) {
  const [status, setStatus] = useState(laporan.status);
  const [tindakan, setTindakan] = useState(laporan.tindakan || '');
  const [saving, setSaving] = useState(false);
  const handleSave = async () => {
    setSaving(true);
    await onSave(laporan.id, status, tindakan);
    setSaving(false);
  };
  return (
    <div className="p-6 space-y-4">
      <div>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Kasus: <span className="text-slate-700 font-bold normal-case">{laporan.judul}</span></p>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-3">Siswa: <span className="text-slate-700 font-bold normal-case">{laporan.siswa?.name}</span></p>
      </div>
      <div>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Status Baru</p>
        <div className="flex gap-2">
          {['Dalam Proses', 'Ditangani', 'Selesai'].map(s => (
            <button
              key={s}
              type="button"
              onClick={() => setStatus(s)}
              className={`flex-1 py-2.5 rounded text-[10px] font-bold border-2 transition-all ${
                status === s
                  ? s === 'Selesai' ? 'bg-green-600 text-white border-green-600'
                  : s === 'Ditangani' ? 'bg-emerald-600 text-white border-emerald-600'
                  : 'bg-amber-500 text-white border-amber-500'
                  : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300'
              }`}
            >{s}</button>
          ))}
        </div>
      </div>
      <div>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Catatan Tindakan</p>
        <textarea
          value={tindakan}
          onChange={e => setTindakan(e.target.value)}
          rows={4}
          placeholder="Isi tindakan yang diambil guru BK..."
          className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400 resize-none"
        />
      </div>
      <div className="flex gap-3 justify-end border-t border-slate-100 pt-4">
        <button type="button" onClick={onCancel} className="px-5 py-2.5 bg-white border border-slate-300 text-slate-600 font-bold rounded text-xs hover:bg-slate-50 transition-all">Batal</button>
        <button type="button" onClick={handleSave} disabled={saving} className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded text-xs transition-all disabled:opacity-60 shadow-lg shadow-emerald-200">
          {saving ? 'Menyimpan...' : 'Simpan Perubahan'}
        </button>
      </div>
    </div>
  );
}

function GuruDashboardContent() {
  const { isAuthorized, isChecking } = useAuthGuard("guru");
  const [namaGuru, setNamaGuru] = useState("Guru BK");
  useEffect(() => {
    try {
      const userStr = localStorage.getItem("user");
      if (userStr) {
        setNamaGuru(JSON.parse(userStr).name);
      }
    } catch {}
  }, []);

  const [newRequests, setNewRequests] = useState([]);
  const [acceptedQueue, setAcceptedQueue] = useState([]);
  const [unreadCounts, setUnreadCounts] = useState({});
  const [allKonseling, setAllKonseling] = useState([]);
  const [activeTab, setActiveTab] = useState('antrean');
  const [queueTab, setQueueTab] = useState('menunggu');
  const [selectedStudentProfile, setSelectedStudentProfile] = useState(null);

  // State Data Siswa
  const [allStudents, setAllStudents] = useState([]);
  const [advisorAdvice, setAdvisorAdvice] = useState(null);

  const fetchAdvisorAdvice = async () => {
    try {
      const response = await fetch('http://localhost:8000/api/analytics/advisor');
      const data = await response.json();
      if (data.success) {
        setAdvisorAdvice(data.data);
      }
    } catch (e) {
      console.error("AI Advisor error:", e);
    }
  };
  const [isLoadingStudents, setIsLoadingStudents] = useState(false);
  const [studentForm, setStudentForm] = useState({
    name: '',
    kelas: '',
    nisn: '',
    password: 'password123'
  });
  const [isSubmittingStudent, setIsSubmittingStudent] = useState(false);

  // State Laporan Kasus Siswa
  const [allLaporan, setAllLaporan] = useState([]);
  const [isLoadingLaporan, setIsLoadingLaporan] = useState(false);
  const [selectedLaporan, setSelectedLaporan] = useState(null);
  const [showLaporanForm, setShowLaporanForm] = useState(false);
  const [laporanStatusFilter, setLaporanStatusFilter] = useState('semua');
  const [laporanForm, setLaporanForm] = useState({
    siswa_id: '',
    judul: '',
    kategori: 'Perilaku',
    deskripsi: '',
    tanggal_kejadian: new Date().toISOString().split('T')[0],
    tingkat_keparahan: 'Ringan',
    tindakan: ''
  });
  const [isSubmittingLaporan, setIsSubmittingLaporan] = useState(false);
  const [editStatusLaporan, setEditStatusLaporan] = useState(null);

  const categoryData = useMemo(() => {
    const counts = {};
    allKonseling.forEach(k => {
      const match = k.topik.match(/\[(.*?)\]/);
      const cat = match ? match[1] : 'Lainnya';
      counts[cat] = (counts[cat] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [allKonseling]);

  const trendData = useMemo(() => {
    const days = {};
    for(let i=6; i>=0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split('T')[0];
      days[dateStr] = 0;
    }
    allKonseling.forEach(k => {
      if (days[k.tanggal] !== undefined) {
        days[k.tanggal]++;
      }
    });
    return Object.entries(days).map(([date, count]) => ({
      date: new Date(date).toLocaleDateString('id-ID', { weekday: 'short' }),
      count
    }));
  }, [allKonseling]);

  useEffect(() => {
    // Notifications are now fetched via API in the main fetchData interval
    // This old localStorage logic is removed to avoid confusion
  }, [namaGuru]);

  const fetchStudents = async () => {
    setIsLoadingStudents(true);
    try {
      const response = await fetch("http://localhost:8000/api/siswa");
      const data = await response.json();
      if (data.success) {
        setAllStudents(data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingStudents(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'data-siswa') {
      fetchStudents();
    }
    if (activeTab === 'laporan-kasus') {
      fetchStudents();
      fetchLaporan();
    }
  }, [activeTab]);

  const fetchLaporan = async () => {
    setIsLoadingLaporan(true);
    try {
      const userStr = localStorage.getItem('user');
      const user = userStr ? JSON.parse(userStr) : null;
      const url = user ? `http://localhost:8000/api/laporan?guru_id=${user.id}` : `http://localhost:8000/api/laporan`;
      const response = await fetch(url);
      const data = await response.json();
      if (data.success) {
        setAllLaporan(data.data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingLaporan(false);
    }
  };

  const handleSubmitLaporan = async (e) => {
    e.preventDefault();
    setIsSubmittingLaporan(true);
    try {
      const userStr = localStorage.getItem('user');
      const user = userStr ? JSON.parse(userStr) : null;
      const payload = { ...laporanForm, guru_id: user?.id };
      const response = await fetch('http://localhost:8000/api/laporan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (data.success) {
        alert('Laporan kasus berhasil dibuat!');
        setLaporanForm({ siswa_id: '', judul: '', kategori: 'Perilaku', deskripsi: '', tanggal_kejadian: new Date().toISOString().split('T')[0], tingkat_keparahan: 'Ringan', tindakan: '' });
        setShowLaporanForm(false);
        fetchLaporan();
      } else {
        alert(data.message || 'Gagal membuat laporan.');
      }
    } catch (e) {
      alert('Terjadi kesalahan.');
    } finally {
      setIsSubmittingLaporan(false);
    }
  };

  const handleUpdateLaporanStatus = async (id, status, tindakan) => {
    try {
      const response = await fetch(`http://localhost:8000/api/laporan/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, tindakan })
      });
      const data = await response.json();
      if (data.success) {
        fetchLaporan();
        setEditStatusLaporan(null);
      } else {
        alert(data.message || 'Gagal memperbarui status.');
      }
    } catch (e) {
      alert('Terjadi kesalahan.');
    }
  };

  const handleDeleteLaporan = async (id) => {
    if (!confirm('Yakin ingin menghapus laporan ini?')) return;
    try {
      const response = await fetch(`http://localhost:8000/api/laporan/${id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) {
        fetchLaporan();
      } else {
        alert(data.message || 'Gagal menghapus laporan.');
      }
    } catch (e) {
      alert('Terjadi kesalahan.');
    }
  };

  const handleAddStudent = async (e) => {
    e.preventDefault();
    setIsSubmittingStudent(true);
    try {
      const response = await fetch("http://localhost:8000/api/siswa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(studentForm)
      });
      const data = await response.json();
      if (data.success) {
        alert("Siswa berhasil ditambahkan!");
        setStudentForm({ name: '', kelas: '', nisn: '', password: 'password123' });
        fetchStudents();
      } else {
        alert(data.message || "Gagal menambahkan siswa.");
      }
    } catch (e) {
      console.error(e);
      alert("Terjadi kesalahan.");
    } finally {
      setIsSubmittingStudent(false);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const userStr = localStorage.getItem('user');
        if (!userStr) return;
        const user = JSON.parse(userStr);

        const response = await fetch(`http://localhost:8000/api/konselings?guru_id=${user.id}`);
        const data = await response.json();

        if (data.success) {
          const pending = [];
          const accepted = [];

          data.data.forEach(k => {
            const req = {
              id: k.id,
              originalId: k.id,
              studentName: k.siswa?.name || 'Siswa Tidak Ditemukan',
              class: k.siswa?.kelas || '-',
              date: k.tanggal,
              time: k.waktu,
              topic: k.topik,
              problem: k.topik,
              status: k.status,
              studentProfile: k.siswa
            };

            if (k.status === 'Menunggu Konfirmasi') {
              pending.push(req);
            } else if (k.status !== 'Ditolak') {
              accepted.push(req);
            }
          });

          setNewRequests(pending);
          setAcceptedQueue(accepted);
          setAllKonseling(data.data);
        }

        // Fetch Unread Chat Counts
        const unreadRes = await fetch(`http://localhost:8000/api/chats/unread?receiver_id=${user.id}`);
        const unreadData = await unreadRes.json();
        if (unreadData.success) {
          const counts = {};
          unreadData.data.forEach(item => {
            counts[item.sender_id] = item.total;
          });
          setUnreadCounts(counts);
        }
      } catch (e) {
        console.error(e);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleProcessRequest = async (id, action) => {
    const newStatus = action === 'setuju' ? 'Terjadwal' : 'Ditolak';
    try {
      const response = await fetch(`http://localhost:8000/api/konselings/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });

      const data = await response.json();
      if (data.success) {
        const requestItem = newRequests.find(req => req.id === id);
        if (requestItem && action === 'setuju') {
          setAcceptedQueue([...acceptedQueue, { ...requestItem, status: 'Terjadwal' }]);
        }
        setNewRequests(newRequests.filter(req => req.id !== id));
      }
    } catch (error) {
      console.error("Error processing request:", error);
    }
  };

  const handleUpdateStatus = async (id, newStatus) => {
    try {
      const response = await fetch(`http://localhost:8000/api/konselings/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });

      const data = await response.json();
      if (data.success) {
        setAcceptedQueue(prev => prev.map(item => {
          if (item.id === id) {
            return { ...item, status: newStatus };
          }
          return item;
        }));
      }
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  if (isChecking) return <div className="min-h-screen bg-slate-100 flex items-center justify-center font-bold">Memuat Dashboard Guru...</div>;
  if (!isAuthorized) return null;

  return (
    <div className="min-h-screen flex font-sans mesh-bg">
      
      {/* Sidebar */}
      <aside className="w-72 bg-[#052e16] border-r border-emerald-900/20 flex flex-col fixed h-full z-40 shadow-2xl">
        
        {/* Logo Section */}
        <div className="p-8 border-b border-white/5 bg-black/10">
          <div className="flex flex-col items-center text-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white shadow-xl flex items-center justify-center p-1.5 animate-scaleIn">
              <img src="/logo-smkn1.jpg" alt="Logo SMKN1" className="w-full h-full object-contain rounded-lg" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white tracking-tight uppercase leading-none">E-Konseling</h1>
              <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-[0.2em] mt-2">Administrator BK</p>
            </div>
          </div>
        </div>

        <nav className="p-6 space-y-2 flex-1 overflow-y-auto">
           {[
             { id: 'antrean', label: 'Antrean Konseling', icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z' },
             { id: 'laporan-kasus', label: 'Laporan Kasus Siswa', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
             { id: 'analitik', label: 'Laporan & Statistik', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
             { id: 'data-siswa', label: 'Database Siswa', icon: 'M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z' },
           ].map((tab) => (
             <button
               key={tab.id}
               onClick={() => setActiveTab(tab.id)}
               className={`w-full group flex items-center gap-3 px-4 py-3.5 rounded-xl text-xs font-bold transition-all relative overflow-hidden ${
                 activeTab === tab.id ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-900/40 text-glow' : 'text-emerald-100/50 hover:bg-white/5 hover:text-white'
               }`}
             >
               <svg className={`w-4 h-4 flex-shrink-0 transition-colors ${activeTab === tab.id ? 'text-white' : 'text-emerald-500/50 group-hover:text-emerald-400'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={tab.icon}></path></svg>
               <span className="text-left">{tab.label}</span>
               {activeTab === tab.id && <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1.5 h-6 bg-amber-400 rounded-l-full shadow-[0_0_8px_rgba(251,191,36,0.6)]" />}
             </button>
           ))}
        </nav>

        <div className="p-6 border-t border-slate-200/5">
           <Link href="/" className="flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 transition-all">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 16l4-4m0 0l-4-4m4 4H7" /></svg>
              Logout Session
           </Link>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 ml-72 p-10 min-h-screen">
        <div className="max-w-7xl mx-auto space-y-10 animate-fadeInUp">
          
          <div className="premium-card p-1 overflow-hidden border-none bg-white/40 backdrop-blur-md">
            <div className="flex flex-col md:flex-row justify-between md:items-center gap-6 p-6">
              <div className="flex items-center gap-6">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-800 shadow-xl flex items-center justify-center p-0.5">
                   <div className="w-full h-full bg-white rounded-xl flex items-center justify-center p-1.5">
                    <img src="/logo-smkn1.jpg" alt="Logo" className="w-full h-full object-contain rounded-lg" />
                   </div>
                </div>
                <div>
                  <h2 className="text-2xl font-black text-slate-900 tracking-tight">Halo, {namaGuru}</h2>
                  <p className="text-sm font-bold text-emerald-600 uppercase tracking-widest mt-1">Dashboard Bimbingan & Konseling</p>
                </div>
              </div>
              <div className="flex items-center gap-3 px-5 py-2.5 rounded-2xl bg-white border border-emerald-100 shadow-sm text-xs font-extrabold text-emerald-700">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                SISTEM ONLINE
              </div>
            </div>
          </div>

          <NotificationBanner />

          {activeTab === 'antrean' && (
            <div className="space-y-6">

              {/* Tab Filter Bar */}
              <div className="bg-white border border-slate-200 rounded shadow-sm overflow-hidden">
                <div className="flex border-b border-slate-200">
                  {[
                    {
                      id: 'menunggu',
                      label: 'Menunggu Konfirmasi',
                      count: newRequests.length,
                      color: 'amber',
                      icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z'
                    },
                    {
                      id: 'terjadwal',
                      label: 'Terjadwal / Berlangsung',
                      count: acceptedQueue.filter(i => i.status === 'Terjadwal' || i.status === 'Sedang Konseling').length,
                      color: 'blue',
                      icon: 'M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z'
                    },
                    {
                      id: 'selesai',
                      label: 'Selesai',
                      count: acceptedQueue.filter(i => i.status === 'Selesai').length,
                      color: 'green',
                      icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z'
                    },
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setQueueTab(tab.id)}
                      className={`flex-1 flex items-center justify-center gap-2 px-4 py-4 text-xs font-bold uppercase tracking-wide transition-all border-b-2 ${
                        queueTab === tab.id
                          ? tab.color === 'amber' ? 'border-amber-500 bg-amber-50 text-amber-700'
                          : tab.color === 'blue' ? 'border-emerald-600 bg-emerald-50 text-emerald-700'
                          : 'border-green-600 bg-green-50 text-green-700'
                          : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={tab.icon} />
                      </svg>
                      {tab.label}
                      {tab.count > 0 && (
                        <span className={`ml-1 px-2 py-0.5 rounded-full text-[9px] font-bold text-white ${
                          tab.color === 'amber' ? 'bg-amber-500' : tab.color === 'blue' ? 'bg-emerald-600' : 'bg-green-600'
                        }`}>{tab.count}</span>
                      )}
                    </button>
                  ))}
                </div>

                {/* Tab: Menunggu Konfirmasi */}
                {queueTab === 'menunggu' && (
                  <div>
                    {newRequests.length === 0 ? (
                      <div className="py-16 text-center text-slate-400">
                        <svg className="w-12 h-12 mx-auto mb-3 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                        <p className="font-bold text-sm">Tidak ada pengajuan baru yang menunggu.</p>
                        <p className="text-xs mt-1">Semua pengajuan sudah diproses.</p>
                      </div>
                    ) : (
                      <div className="divide-y divide-slate-100">
                        {newRequests.map(req => (
                          <div key={req.id} className="p-6 flex flex-col md:flex-row items-center justify-between gap-4 hover:bg-amber-50 transition-colors">
                            <div className="flex items-center gap-4 flex-1">
                              <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded border border-amber-200 flex items-center justify-center font-bold text-lg flex-shrink-0">{req.studentName.charAt(0)}</div>
                              <div>
                                <p className="font-bold text-slate-800">{req.studentName}</p>
                                <p className="text-xs text-slate-500 mt-0.5 font-medium">{req.class} • {req.date} pukul {req.time}</p>
                                <p className="text-xs text-amber-700 font-semibold mt-1 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded inline-block">Topik: {req.topic}</p>
                              </div>
                            </div>
                            <div className="flex gap-2 w-full md:w-auto flex-shrink-0">
                              <button onClick={() => handleProcessRequest(req.id, 'tolak')} className="flex-1 md:flex-none px-5 py-2.5 bg-white border border-slate-300 text-slate-600 font-bold rounded text-xs hover:bg-red-50 hover:border-red-300 hover:text-red-600 transition-all">TOLAK</button>
                              <button onClick={() => { handleProcessRequest(req.id, 'setuju'); setQueueTab('terjadwal'); }} className="flex-1 md:flex-none px-5 py-2.5 bg-emerald-600 text-white font-bold rounded text-xs hover:bg-emerald-700 shadow-md transition-all">SETUJUI JADWAL</button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Tab: Terjadwal / Berlangsung */}
                {queueTab === 'terjadwal' && (() => {
                  const filtered = acceptedQueue.filter(i => i.status === 'Terjadwal' || i.status === 'Sedang Konseling');
                  return (
                    <div className="overflow-x-auto">
                      <table className="edu-table">
                        <thead>
                          <tr>
                            <th>Nama & Kelas Siswa</th>
                            <th>Topik/Hal Utama</th>
                            <th>Jadwal Pukul</th>
                            <th>Status</th>
                            <th className="text-center">Aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.length === 0 ? (
                            <tr><td colSpan="5" className="py-16 text-center text-slate-400 font-medium italic">Belum ada konseling yang terjadwal saat ini.</td></tr>
                          ) : filtered.map(item => (
                            <tr key={item.id}>
                              <td>
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-slate-100 border border-slate-200 rounded flex items-center justify-center font-bold text-slate-400 overflow-hidden">
                                    {item.studentProfile?.photo ? <img src={`http://localhost:8000/storage/${item.studentProfile.photo}`} className="w-full h-full object-cover" /> : item.studentName.charAt(0)}
                                  </div>
                                  <div>
                                    <p className="font-bold text-slate-800">{item.studentName}</p>
                                    <p className="text-[10px] text-slate-500 font-bold uppercase">{item.class}</p>
                                  </div>
                                </div>
                              </td>
                              <td><p className="text-sm font-medium text-slate-600 truncate max-w-[200px]">{item.problem}</p></td>
                              <td><span className="text-sm font-bold text-slate-700">{item.date} • {item.time}</span></td>
                              <td>
                                <span className={`px-3 py-1 rounded text-[10px] font-bold border ${
                                  item.status === 'Sedang Konseling' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-slate-50 text-slate-500 border-slate-200'
                                }`}>{item.status.toUpperCase()}</span>
                              </td>
                              <td>
                                <div className="flex items-center justify-center gap-2">
                                  {item.status === 'Terjadwal' && (
                                    <button onClick={() => handleUpdateStatus(item.id, 'Sedang Konseling')} className="px-3 py-1.5 bg-emerald-600 text-white hover:bg-emerald-700 rounded text-[10px] font-bold transition-all">MULAI SESI</button>
                                  )}
                                  {item.status === 'Sedang Konseling' && (
                                    <button onClick={() => { handleUpdateStatus(item.id, 'Selesai'); setQueueTab('selesai'); }} className="px-3 py-1.5 bg-green-600 text-white hover:bg-green-700 rounded text-[10px] font-bold transition-all">SELESAI</button>
                                  )}
                                  <Link href={`/chat?targetId=${item.studentProfile?.id}&targetName=${encodeURIComponent(item.studentName)}&targetRole=siswa`} className="p-2 border border-slate-200 hover:bg-emerald-50 hover:text-emerald-600 rounded text-slate-400 transition-all relative">
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
                                    {unreadCounts[item.studentProfile?.id] > 0 && (
                                      <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full border border-white shadow-sm ring-1 ring-white">
                                        {unreadCounts[item.studentProfile?.id]}
                                      </span>
                                    )}
                                  </Link>
                                  <button onClick={() => setSelectedStudentProfile(item.studentProfile)} className="p-2 border border-slate-200 hover:bg-slate-50 rounded text-slate-400 transition-all">
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                })()}

                {/* Tab: Selesai */}
                {queueTab === 'selesai' && (() => {
                  const filtered = acceptedQueue.filter(i => i.status === 'Selesai');
                  return (
                    <div className="overflow-x-auto">
                      <table className="edu-table">
                        <thead>
                          <tr>
                            <th>Nama & Kelas Siswa</th>
                            <th>Topik/Hal Utama</th>
                            <th>Jadwal</th>
                            <th>Status</th>
                            <th className="text-center">Aksi</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.length === 0 ? (
                            <tr><td colSpan="5" className="py-16 text-center text-slate-400 font-medium italic">Belum ada konseling yang selesai.</td></tr>
                          ) : filtered.map(item => (
                            <tr key={item.id}>
                              <td>
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-green-50 border border-green-200 rounded flex items-center justify-center font-bold text-green-400 overflow-hidden">
                                    {item.studentProfile?.photo ? <img src={`http://localhost:8000/storage/${item.studentProfile.photo}`} className="w-full h-full object-cover" /> : item.studentName.charAt(0)}
                                  </div>
                                  <div>
                                    <p className="font-bold text-slate-800">{item.studentName}</p>
                                    <p className="text-[10px] text-slate-500 font-bold uppercase">{item.class}</p>
                                  </div>
                                </div>
                              </td>
                              <td><p className="text-sm font-medium text-slate-600 truncate max-w-[200px]">{item.problem}</p></td>
                              <td><span className="text-sm text-slate-500">{item.date} • {item.time}</span></td>
                              <td><span className="px-3 py-1 rounded text-[10px] font-bold border bg-green-50 text-green-700 border-green-200">SELESAI</span></td>
                              <td>
                                <div className="flex items-center justify-center gap-2">
                                  <Link href={`/chat?targetId=${item.studentProfile?.id}&targetName=${encodeURIComponent(item.studentName)}&targetRole=siswa`} className="p-2 border border-slate-200 hover:bg-slate-50 rounded text-slate-400 transition-all relative">
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
                                    {unreadCounts[item.studentProfile?.id] > 0 && (
                                      <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[8px] font-bold px-1.5 py-0.5 rounded-full border border-white shadow-sm">
                                        {unreadCounts[item.studentProfile?.id]}
                                      </span>
                                    )}
                                  </Link>
                                  <button onClick={() => setSelectedStudentProfile(item.studentProfile)} className="p-2 border border-slate-200 hover:bg-slate-50 rounded text-slate-400 transition-all">
                                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                })()}

              </div>
            </div>
          )}

          {activeTab === 'laporan-kasus' && (
            <div className="space-y-6 animate-in fade-in">

              {/* Header Laporan Kasus */}
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-bold text-slate-800 uppercase tracking-wide">Laporan Kasus Siswa</h3>
                  <p className="text-sm text-slate-500 mt-0.5">Dokumentasi kasus dan permasalahan siswa di sekolah</p>
                </div>
                <button
                  onClick={() => setShowLaporanForm(!showLaporanForm)}
                  className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded text-xs transition-all shadow-md"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" /></svg>
                  {showLaporanForm ? 'Tutup Formulir' : 'Buat Laporan Baru'}
                </button>
              </div>

              {/* Form Buat Laporan */}
              {showLaporanForm && (
                <div className="bg-white border-2 border-rose-200 rounded shadow-sm overflow-hidden">
                  <div className="bg-rose-50 px-6 py-4 border-b border-rose-200">
                    <h4 className="font-bold text-rose-800 uppercase text-sm tracking-wide flex items-center gap-2">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                      Formulir Laporan Kasus
                    </h4>
                  </div>
                  <form onSubmit={handleSubmitLaporan} className="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
                    
                    {/* Pilih Siswa */}
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Nama Siswa yang Bersangkutan <span className="text-rose-500">*</span></label>
                      <select
                        value={laporanForm.siswa_id}
                        onChange={e => setLaporanForm({...laporanForm, siswa_id: e.target.value})}
                        className="w-full border border-slate-300 rounded px-3 py-2 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-rose-400"
                        required
                      >
                        <option value="">-- Pilih Siswa --</option>
                        {allStudents.map(s => (
                          <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Judul Kasus */}
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Judul / Ringkasan Kasus <span className="text-rose-500">*</span></label>
                      <input
                        type="text"
                        value={laporanForm.judul}
                        onChange={e => setLaporanForm({...laporanForm, judul: e.target.value})}
                        placeholder="Contoh: Pelanggaran Disiplin – Tidak Masuk Tanpa Keterangan"
                        className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400"
                        required
                      />
                    </div>

                    {/* Kategori */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Kategori Kasus</label>
                      <select
                        value={laporanForm.kategori}
                        onChange={e => setLaporanForm({...laporanForm, kategori: e.target.value})}
                        className="w-full border border-slate-300 rounded px-3 py-2 text-sm font-medium text-slate-700 focus:outline-none focus:ring-2 focus:ring-rose-400"
                      >
                        {['Perilaku', 'Akademik', 'Kehadiran', 'Bullying', 'Narkoba', 'Lainnya'].map(k => (
                          <option key={k} value={k}>{k}</option>
                        ))}
                      </select>
                    </div>

                    {/* Tanggal Kejadian */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Tanggal Kejadian</label>
                      <input
                        type="date"
                        value={laporanForm.tanggal_kejadian}
                        onChange={e => setLaporanForm({...laporanForm, tanggal_kejadian: e.target.value})}
                        className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400"
                        required
                      />
                    </div>

                    {/* Tingkat Keparahan */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Tingkat Keparahan</label>
                      <div className="flex gap-3">
                        {[{val:'Ringan', color:'green'}, {val:'Sedang', color:'amber'}, {val:'Berat', color:'rose'}].map(({val, color}) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => setLaporanForm({...laporanForm, tingkat_keparahan: val})}
                            className={`flex-1 py-2 rounded text-xs font-bold border-2 transition-all ${
                              laporanForm.tingkat_keparahan === val
                                ? color === 'green' ? 'bg-green-600 text-white border-green-600'
                                : color === 'amber' ? 'bg-amber-500 text-white border-amber-500'
                                : 'bg-rose-600 text-white border-rose-600'
                                : 'bg-white text-slate-500 border-slate-200 hover:border-slate-300'
                            }`}
                          >{val}</button>
                        ))}
                      </div>
                    </div>

                    {/* Deskripsi */}
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Uraian / Deskripsi Kasus <span className="text-rose-500">*</span></label>
                      <textarea
                        value={laporanForm.deskripsi}
                        onChange={e => setLaporanForm({...laporanForm, deskripsi: e.target.value})}
                        rows={4}
                        placeholder="Uraikan kejadian secara detail: kapan, di mana, apa yang terjadi..."
                        className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none"
                        required
                      />
                    </div>

                    {/* Tindakan Awal */}
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1.5">Tindakan Awal yang Diambil <span className="text-slate-300">(opsional)</span></label>
                      <textarea
                        value={laporanForm.tindakan}
                        onChange={e => setLaporanForm({...laporanForm, tindakan: e.target.value})}
                        rows={3}
                        placeholder="Contoh: Siswa dipanggil ke ruang BK, orang tua dihubungi..."
                        className="w-full border border-slate-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-rose-400 resize-none"
                      />
                    </div>

                    <div className="md:col-span-2 flex justify-end gap-3 pt-2 border-t border-slate-100">
                      <button type="button" onClick={() => setShowLaporanForm(false)} className="px-6 py-2.5 bg-white border border-slate-300 text-slate-600 font-bold rounded text-xs hover:bg-slate-50 transition-all">Batal</button>
                      <button type="submit" disabled={isSubmittingLaporan} className="px-8 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded text-xs transition-all shadow-md disabled:opacity-60">
                        {isSubmittingLaporan ? 'Menyimpan...' : '📋 Simpan Laporan'}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Filter Status */}
              <div className="bg-white border border-slate-200 rounded shadow-sm overflow-hidden">
                <div className="flex border-b border-slate-200">
                  {[
                    { id: 'semua', label: 'Semua', count: allLaporan.length },
                    { id: 'Dalam Proses', label: 'Dalam Proses', count: allLaporan.filter(l => l.status === 'Dalam Proses').length },
                    { id: 'Ditangani', label: 'Ditangani', count: allLaporan.filter(l => l.status === 'Ditangani').length },
                    { id: 'Selesai', label: 'Selesai', count: allLaporan.filter(l => l.status === 'Selesai').length },
                  ].map(f => (
                    <button
                      key={f.id}
                      onClick={() => setLaporanStatusFilter(f.id)}
                      className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 text-xs font-bold uppercase tracking-wide transition-all border-b-2 ${
                        laporanStatusFilter === f.id
                          ? 'border-rose-500 bg-rose-50 text-rose-700'
                          : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      {f.label}
                      {f.count > 0 && <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold text-white ${laporanStatusFilter === f.id ? 'bg-rose-500' : 'bg-slate-400'}`}>{f.count}</span>}
                    </button>
                  ))}
                </div>

                {/* Daftar Laporan */}
                {isLoadingLaporan ? (
                  <div className="py-16 text-center text-slate-400 font-medium text-sm">Memuat data laporan...</div>
                ) : (() => {
                  const filtered = laporanStatusFilter === 'semua'
                    ? allLaporan
                    : allLaporan.filter(l => l.status === laporanStatusFilter);
                  return filtered.length === 0 ? (
                    <div className="py-16 text-center text-slate-400">
                      <svg className="w-12 h-12 mx-auto mb-3 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                      <p className="font-bold text-sm">Belum ada laporan kasus.</p>
                      <p className="text-xs mt-1">Klik tombol "Buat Laporan Baru" untuk mendokumentasikan kasus siswa.</p>
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-100">
                      {filtered.map(lap => (
                        <div key={lap.id} className="p-5 hover:bg-slate-50 transition-colors">
                          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                            <div className="flex-1">
                              {/* Header baris laporan */}
                              <div className="flex flex-wrap items-center gap-2 mb-2">
                                <span className={`px-2.5 py-1 rounded text-[9px] font-bold uppercase border ${
                                  lap.tingkat_keparahan === 'Berat' ? 'bg-rose-100 text-rose-700 border-rose-200'
                                  : lap.tingkat_keparahan === 'Sedang' ? 'bg-amber-100 text-amber-700 border-amber-200'
                                  : 'bg-green-100 text-green-700 border-green-200'
                                }`}>{lap.tingkat_keparahan}</span>
                                <span className="px-2.5 py-1 rounded text-[9px] font-bold uppercase border bg-slate-100 text-slate-600 border-slate-200">{lap.kategori}</span>
                                <span className={`px-2.5 py-1 rounded text-[9px] font-bold uppercase border ${
                                  lap.status === 'Selesai' ? 'bg-green-50 text-green-700 border-green-200'
                                  : lap.status === 'Ditangani' ? 'bg-blue-50 text-blue-700 border-blue-200'
                                  : 'bg-amber-50 text-amber-700 border-amber-200'
                                }`}>{lap.status}</span>
                              </div>
                              <h5 className="font-bold text-slate-800 text-sm mb-1">{lap.judul}</h5>
                              <div className="flex items-center gap-3 text-xs text-slate-500 mb-2">
                                <span className="flex items-center gap-1"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg><strong>{lap.siswa?.name}</strong> — {lap.siswa?.kelas}</span>
                                <span>•</span>
                                <span className="flex items-center gap-1"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>{lap.tanggal_kejadian}</span>
                              </div>
                              <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">{lap.deskripsi}</p>
                              {lap.tindakan && (
                                <p className="text-xs text-blue-700 mt-1.5 bg-blue-50 border border-blue-100 rounded px-2.5 py-1.5">🔧 Tindakan: {lap.tindakan}</p>
                              )}
                            </div>

                            {/* Tombol Aksi */}
                            <div className="flex flex-col gap-2 min-w-[140px]">
                              <button
                                onClick={() => setSelectedLaporan(lap)}
                                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded text-[10px] uppercase transition-all"
                              >Detail</button>
                              <a
                                href={`http://localhost:8000/api/laporan/${lap.id}/export-pdf`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-center font-bold rounded text-[10px] uppercase transition-all"
                              >Cetak PDF</a>
                              {lap.status !== 'Selesai' && (
                                <button
                                  onClick={() => setEditStatusLaporan(lap)}
                                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded text-[10px] uppercase transition-all"
                                >Update Status</button>
                              )}
                              <button
                                onClick={() => handleDeleteLaporan(lap.id)}
                                className="px-4 py-2 bg-white border border-rose-200 hover:bg-rose-50 text-rose-600 font-bold rounded text-[10px] uppercase transition-all"
                              >Hapus</button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  );
                })()}
              </div>
            </div>
          )}

          {activeTab === 'analitik' && (
            <div className="space-y-8 animate-in fade-in">
               {/* Sentinel AI Advisor Section */}
               {advisorAdvice && advisorAdvice.advices.length > 0 && (
                 <div className={`p-6 border-l-4 rounded-r shadow-sm flex gap-4 items-start ${
                    advisorAdvice.advices[0].level === 'danger' ? 'bg-rose-50 border-rose-500' :
                    advisorAdvice.advices[0].level === 'warning' ? 'bg-amber-50 border-amber-500' :
                    advisorAdvice.advices[0].level === 'info' ? 'bg-blue-50 border-blue-500' :
                    'bg-emerald-50 border-emerald-500'
                 }`}>
                    <div className={`p-3 rounded-full ${
                        advisorAdvice.advices[0].level === 'danger' ? 'bg-rose-100 text-rose-600' :
                        advisorAdvice.advices[0].level === 'warning' ? 'bg-amber-100 text-amber-600' :
                        advisorAdvice.advices[0].level === 'info' ? 'bg-blue-100 text-blue-600' :
                        'bg-emerald-100 text-emerald-600'
                    }`}>
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    </div>
                    <div>
                        <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 bg-white/50 rounded border border-black/5">AI Sentinel Advisor</span>
                            <h4 className="font-extrabold text-slate-800 text-sm">{advisorAdvice.advices[0].title}</h4>
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed max-w-3xl">{advisorAdvice.advices[0].message}</p>
                        <p className="text-[9px] text-slate-400 font-bold mt-2 uppercase italic">*Saran ini dihasilkan berdasarkan pola data anonim dan bertujuan sebagai pendukung keputusan klinis.</p>
                    </div>
                 </div>
               )}

               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    { label: "Total Pengajuan Masuk", value: allKonseling.length },
                    { label: "Siswa Selesai Dibimbing", value: allKonseling.filter(k => k.status === 'Selesai').length },
                    { label: "Total Database Siswa", value: allStudents.length },
                  ].map((stat, i) => (
                    <div key={i} className="bg-white p-6 border border-slate-200 rounded text-center shadow-sm">
                       <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                       <p className="text-3xl font-extrabold text-blue-800">{stat.value}</p>
                    </div>
                  ))}
               </div>

               <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div className="bg-white p-6 border border-slate-200 rounded shadow-sm">
                     <h4 className="font-bold text-slate-800 mb-6 uppercase text-sm border-b pb-3">Statistik Kategori Masalah</h4>
                     <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                           <BarChart data={categoryData}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} />
                              <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} />
                              <YAxis stroke="#94a3b8" fontSize={10} />
                              <Tooltip cursor={{fill: '#f1f5f9'}} />
                              <Bar dataKey="value" fill="#1e40af" radius={[4, 4, 0, 0]} barSize={30} />
                           </BarChart>
                        </ResponsiveContainer>
                     </div>
                  </div>

                  <div className="bg-white p-6 border border-slate-200 rounded shadow-sm">
                     <h4 className="font-bold text-slate-800 mb-6 uppercase text-sm border-b pb-3">Grafik Aktivitas Layanan Mingguan</h4>
                     <div className="h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                           <AreaChart data={trendData}>
                              <CartesianGrid strokeDasharray="3 3" vertical={false} />
                              <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} />
                              <YAxis stroke="#94a3b8" fontSize={10} />
                              <Tooltip />
                              <Area type="monotone" dataKey="count" stroke="#1e40af" strokeWidth={2} fill="#eff6ff" />
                           </AreaChart>
                        </ResponsiveContainer>
                     </div>
                  </div>
               </div>
            </div>
          )}

          {activeTab === 'data-siswa' && (
            <div className="space-y-8">
               <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                  <div className="lg:col-span-1">
                     <div className="bg-white border border-slate-300 rounded p-6 shadow-sm sticky top-8">
                        <h4 className="font-bold text-slate-800 mb-6 uppercase text-sm border-b pb-3">Formulir Input Siswa</h4>
                        <form onSubmit={handleAddStudent} className="space-y-4">
                           <div>
                              <label className="text-[10px] font-bold text-slate-500 uppercase">Nama Siswa</label>
                              <input type="text" value={studentForm.name} onChange={e=>setStudentForm({...studentForm, name:e.target.value})} className="border-slate-300 rounded text-sm py-2" required />
                           </div>
                           <div>
                              <label className="text-[10px] font-bold text-slate-500 uppercase">Kelas</label>
                              <input type="text" value={studentForm.kelas} onChange={e=>setStudentForm({...studentForm, kelas:e.target.value})} className="border-slate-300 rounded text-sm py-2" required />
                           </div>
                           <div>
                              <label className="text-[10px] font-bold text-slate-500 uppercase">NISN</label>
                              <input type="text" value={studentForm.nisn} onChange={e=>setStudentForm({...studentForm, nisn:e.target.value})} className="border-slate-300 rounded text-sm py-2" required />
                           </div>
                           <button disabled={isSubmittingStudent} className="w-full py-3 bg-blue-700 hover:bg-blue-800 text-white font-bold rounded text-xs transition-all shadow-md mt-2">DAFTARKAN KE SISTEM</button>
                        </form>
                     </div>
                  </div>

                  <div className="lg:col-span-3 bg-white border border-slate-300 rounded shadow-sm overflow-hidden">
                     <div className="bg-slate-50 p-6 border-b border-slate-200">
                        <h3 className="font-bold text-slate-800 uppercase text-sm tracking-widest">Daftar Seluruh Siswa Terdaftar</h3>
                     </div>
                     <div className="overflow-x-auto">
                        <table className="edu-table">
                           <thead>
                              <tr>
                                 <th>Profil Lengkap</th>
                                 <th>Kelas/Rombel</th>
                                 <th>NISN</th>
                                 <th className="text-right">Operasional</th>
                              </tr>
                           </thead>
                           <tbody className="text-sm">
                              {allStudents.map(s => (
                                <tr key={s.id}>
                                   <td className="font-bold text-slate-800 flex items-center gap-3">
                                      <div className="w-8 h-8 bg-slate-200 rounded flex items-center justify-center font-bold text-xs">{s.name.charAt(0)}</div>
                                      {s.name}
                                   </td>
                                   <td className="text-slate-500 font-medium">{s.kelas}</td>
                                   <td className="text-slate-400 font-mono tracking-tighter">{s.nisn}</td>
                                   <td className="text-right">
                                      <button onClick={()=>setSelectedStudentProfile(s)} className="text-[10px] font-bold text-blue-600 hover:underline">LIHAT DETAIL</button>
                                   </td>
                                </tr>
                              ))}
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
          )}
        </div>
      </main>

      {/* Modal Detail Laporan */}
      {selectedLaporan && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white border-2 border-rose-500 w-full max-w-2xl rounded shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="bg-rose-50 px-8 py-5 border-b border-rose-200 flex items-center justify-between">
              <h4 className="font-bold text-rose-800 uppercase text-sm tracking-widest">Detail Laporan Kasus</h4>
              <button onClick={() => setSelectedLaporan(null)} className="text-slate-400 hover:text-rose-500 font-bold transition-colors text-lg leading-none">✕</button>
            </div>
            <div className="p-8 space-y-5">
              <div className="flex flex-wrap gap-2">
                <span className={`px-3 py-1 rounded text-xs font-bold border ${
                  selectedLaporan.tingkat_keparahan === 'Berat' ? 'bg-rose-100 text-rose-700 border-rose-200'
                  : selectedLaporan.tingkat_keparahan === 'Sedang' ? 'bg-amber-100 text-amber-700 border-amber-200'
                  : 'bg-green-100 text-green-700 border-green-200'
                }`}>{selectedLaporan.tingkat_keparahan}</span>
                <span className="px-3 py-1 rounded text-xs font-bold border bg-slate-100 text-slate-600 border-slate-200">{selectedLaporan.kategori}</span>
                <span className={`px-3 py-1 rounded text-xs font-bold border ${
                  selectedLaporan.status === 'Selesai' ? 'bg-green-50 text-green-700 border-green-200'
                  : selectedLaporan.status === 'Ditangani' ? 'bg-blue-50 text-blue-700 border-blue-200'
                  : 'bg-amber-50 text-amber-700 border-amber-200'
                }`}>{selectedLaporan.status}</span>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Judul Kasus</p>
                <h5 className="font-bold text-slate-900 text-base">{selectedLaporan.judul}</h5>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Siswa</p>
                  <p className="font-bold text-slate-800">{selectedLaporan.siswa?.name}</p>
                  <p className="text-xs text-slate-500">{selectedLaporan.siswa?.kelas}</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Tanggal Kejadian</p>
                  <p className="font-bold text-slate-800">{selectedLaporan.tanggal_kejadian}</p>
                  <p className="text-xs text-slate-500">Dibuat: {selectedLaporan.created_at}</p>
                </div>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Deskripsi Kasus</p>
                <div className="p-4 bg-slate-50 border border-slate-200 rounded text-sm text-slate-700 leading-relaxed whitespace-pre-line">{selectedLaporan.deskripsi}</div>
              </div>
              {selectedLaporan.tindakan && (
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Tindakan yang Diambil</p>
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded text-sm text-blue-800 leading-relaxed">{selectedLaporan.tindakan}</div>
                </div>
              )}
              <div className="flex justify-end gap-3 pt-2 border-t border-slate-100">
                <button onClick={() => setSelectedLaporan(null)} className="px-6 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded text-xs transition-all">Tutup</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Update Status Laporan */}
      {editStatusLaporan && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white border-2 border-blue-500 w-full max-w-md rounded shadow-2xl overflow-hidden animate-in zoom-in-95">
            <div className="bg-blue-50 px-8 py-5 border-b border-blue-200 flex items-center justify-between">
              <h4 className="font-bold text-blue-800 uppercase text-sm tracking-widest">Update Status Laporan</h4>
              <button onClick={() => setEditStatusLaporan(null)} className="text-slate-400 hover:text-rose-500 font-bold transition-colors text-lg leading-none">✕</button>
            </div>
            <UpdateStatusForm laporan={editStatusLaporan} onSave={handleUpdateLaporanStatus} onCancel={() => setEditStatusLaporan(null)} />
          </div>
        </div>
      )}

      {/* Profil Modal Formal */}
      {selectedStudentProfile && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white border-4 border-blue-600 w-full max-w-lg rounded shadow-2xl overflow-hidden animate-in zoom-in-95">
              <div className="bg-slate-100 px-8 py-6 border-b border-slate-200 flex items-center justify-between">
                 <h4 className="font-bold text-slate-800 uppercase text-sm tracking-widest">Detail Profil Siswa</h4>
                 <button onClick={()=>setSelectedStudentProfile(null)} className="text-slate-400 hover:text-rose-500 font-bold transition-colors">X</button>
              </div>
              <div className="p-10 space-y-8">
                 <div className="flex items-center gap-6 pb-6 border-b border-slate-100">
                    <div className="w-20 h-20 bg-slate-100 border border-slate-200 rounded flex items-center justify-center font-extrabold text-2xl text-blue-800 overflow-hidden">
                       {selectedStudentProfile.photo ? <img src={`http://localhost:8000/storage/${selectedStudentProfile.photo}`} className="w-full h-full object-cover" /> : selectedStudentProfile.name.charAt(0)}
                    </div>
                    <div>
                       <h5 className="text-xl font-bold text-slate-900">{selectedStudentProfile.name}</h5>
                       <p className="text-sm font-bold text-blue-700 uppercase mt-0.5">Siswa Kelas {selectedStudentProfile.kelas}</p>
                    </div>
                 </div>

                 <div className="grid grid-cols-1 gap-6">
                    <div>
                       <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Minat & Hobi</p>
                       <div className="p-4 bg-slate-50 border border-slate-200 rounded text-sm text-slate-700 font-medium leading-relaxed">{selectedStudentProfile.hobi || "Data tidak tersedia."}</div>
                    </div>
                    <div>
                       <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Rencana Karir/Studi Lanjut</p>
                       <div className="p-4 bg-slate-50 border border-slate-200 rounded text-sm text-slate-700 font-medium leading-relaxed">{selectedStudentProfile.rencana_masa_depan || "Data tidak tersedia."}</div>
                    </div>
                 </div>

                 <Link href={`/chat?targetId=${selectedStudentProfile.id}&targetName=${encodeURIComponent(selectedStudentProfile.name)}&targetRole=siswa`} className="block w-full py-4 bg-blue-800 hover:bg-blue-900 text-white font-bold rounded shadow-md text-center transition-all uppercase text-xs tracking-widest">Hubungi Siswa Melalui Chat</Link>
              </div>
           </div>
        </div>
      )}
    </div>
  );
}

export default function GuruDashboard() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-slate-100 flex items-center justify-center font-bold">Memuat Dashboard...</div>}>
      <GuruDashboardContent />
    </Suspense>
  );
}
