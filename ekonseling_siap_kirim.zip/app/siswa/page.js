"use client";
import Link from "next/link";
import { useState, Suspense, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { useAuthGuard } from "../hooks/useAuthGuard";
import NotificationBanner from "../components/NotificationBanner";

function SiswaDashboardContent() {
  const { isAuthorized, isChecking } = useAuthGuard("siswa");
  const searchParams = useSearchParams();
  const namaSiswa = searchParams.get("nama") || "Siswa";
  const kelasSiswa = searchParams.get("kelas") || "Umum";
  const [schedules, setSchedules] = useState([]);
  const [isLoadingSchedules, setIsLoadingSchedules] = useState(true);

  const [selectedSchedule, setSelectedSchedule] = useState(null);
  const [kategori, setKategori] = useState("");
  const [kebutuhan, setKebutuhan] = useState("");
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [isSuccess, setIsSuccess] = useState(false);
  const [myBookings, setMyBookings] = useState([]);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [historyTab, setHistoryTab] = useState('aktif');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchGuru, setSearchGuru] = useState("");
  
  const [profileData, setProfileData] = useState({
    hobi: "",
    rencana_masa_depan: "",
    photo: null,
    previewUrl: null
  });
  const [isUpdatingProfile, setIsUpdatingProfile] = useState(false);

  useEffect(() => {
    const fetchBookingsAndSurat = async () => {
      try {
        const userStr = localStorage.getItem('user');
        if (!userStr) return;
        const user = JSON.parse(userStr);
        setProfileData(prev => ({
          ...prev,
          hobi: user.hobi || "",
          rencana_masa_depan: user.rencana_masa_depan || "",
          previewUrl: user.photo ? `http://localhost:8000/storage/${user.photo}` : null
        }));
        
        const response = await fetch(`http://localhost:8000/api/konselings?siswa_id=${user.id}`);
        const data = await response.json();
        
        if (data.success) {
          setMyBookings(data.data.map(k => ({
            id: k.id,
            guruName: k.guru.name,
            date: k.tanggal,
            time: k.waktu,
            status: k.status,
            kebutuhan: k.topik
          })));
        }
      } catch (error) {
        console.error(error);
      }
    };
    
    const fetchSchedules = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/schedules");
        const data = await response.json();
        if (data.success) {
          const formatted = data.data.map(s => ({
            id: s.id,
            guruId: s.guru_id,
            name: s.guru_name,
            specialty: "Guru Bimbingan Konseling",
            date: "Senin - Jumat",
            time: "07:30 - 15:30 WIB",
            status: s.status,
            avatar: s.guru_name.charAt(0)
          }));
          const guruMap = new Map();
          formatted.forEach(item => {
            const existing = guruMap.get(item.guruId);
            if (!existing) {
              guruMap.set(item.guruId, item);
            } else {
              guruMap.set(item.guruId, {
                ...existing,
                status:
                  existing.status === "Tersedia" || item.status === "Tersedia"
                    ? "Tersedia"
                    : existing.status,
              });
            }
          });
          setSchedules(Array.from(guruMap.values()));
        }
      } catch (error) {
        console.error(error);
      } finally {
        setIsLoadingSchedules(false);
      }
    };

    fetchSchedules();
    fetchBookingsAndSurat();
    const interval = setInterval(fetchBookingsAndSurat, 3000);
    return () => clearInterval(interval);
  }, []);

  const [unreadCounts, setUnreadCounts] = useState({});

  useEffect(() => {
    const fetchUnread = async () => {
      try {
        const userStr = localStorage.getItem('user');
        if (!userStr) return;
        const user = JSON.parse(userStr);
        
        const response = await fetch(`http://localhost:8000/api/chats/unread?receiver_id=${user.id}`);
        const data = await response.json();
        if (data.success) {
          const counts = {};
          data.data.forEach(item => {
            counts[item.sender_id] = item.total;
          });
          setUnreadCounts(counts);
        }
      } catch (error) {
        console.error("Unread fetch error:", error);
      }
    };
    fetchUnread();
    const interval = setInterval(fetchUnread, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleDaftar = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;

    const userStr = localStorage.getItem('user');
    if (!userStr) {
      alert("Sesi anda telah berakhir. Silakan login kembali.");
      return;
    }
    const user = JSON.parse(userStr);

    if (!selectedSchedule || !selectedDate || !selectedTime || !kebutuhan) {
      alert("Mohon lengkapi semua data pengajuan.");
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch("http://localhost:8000/api/konselings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          siswa_id: user.id || user.id_user,
          guru_id: selectedSchedule.guruId,
          guru_name: selectedSchedule.name,
          tanggal: selectedDate,
          waktu: selectedTime,
          topik: kategori ? `[${kategori}] ${kebutuhan}` : kebutuhan
        })
      });

      const data = await response.json();
      if (data.success) {
        setIsSuccess(true);
        // Safely update myBookings
        const newBooking = { 
          id: data.data?.id || Date.now(), 
          guruName: selectedSchedule.name, 
          date: selectedDate, 
          time: selectedTime, 
          status: "Menunggu Konfirmasi", 
          kebutuhan: kebutuhan 
        };
        setMyBookings(prev => [newBooking, ...prev]);
        
        setTimeout(() => {
          setIsSuccess(false);
          setSelectedSchedule(null);
          setKategori(""); setKebutuhan(""); setSelectedDate(""); setSelectedTime("");
          setIsSubmitting(false);
        }, 2000);
      } else {
        alert(data.message || "Gagal membuat jadwal bimbingan.");
        setIsSubmitting(false);
      }
    } catch (e) {
      console.error(e);
      alert("Terjadi kesalahan koneksi ke server.");
      setIsSubmitting(false);
    }
  };

  const handleCancelBooking = async (id) => {
    if (!confirm("Apakah Anda yakin ingin membatalkan konseling ini?")) return;
    try {
      const response = await fetch(`http://localhost:8000/api/konselings/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "Dibatalkan" })
      });
      const data = await response.json();
      if (data.success) {
        setMyBookings(prev => prev.map(b => b.id === id ? { ...b, status: "Dibatalkan" } : b));
      }
    } catch (e) {
      console.error(e);
      alert("Gagal membatalkan konseling.");
    }
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    setIsUpdatingProfile(true);
    const userStr = localStorage.getItem('user');
    const user = JSON.parse(userStr);
    const formData = new FormData();
    formData.append('user_id', user.id);
    formData.append('hobi', profileData.hobi);
    formData.append('rencana_masa_depan', profileData.rencana_masa_depan);
    if (profileData.photo) formData.append('photo', profileData.photo);

    try {
      const response = await fetch("http://localhost:8000/api/update-profile", {
        method: "POST",
        body: formData
      });
      const data = await response.json();
      if (data.success) {
        localStorage.setItem('user', JSON.stringify(data.user));
        setProfileData(prev => ({ ...prev, photo: null, previewUrl: data.user.photo ? `http://localhost:8000/storage/${data.user.photo}` : null }));
        alert("Profil berhasil diperbarui.");
      }
    } catch (e) {
      console.error(e);
      alert("Gagal memperbarui profil.");
    } finally {
      setIsUpdatingProfile(false);
    }
  };

  if (!isAuthorized) return null;

  const activeBookings = myBookings.filter(b => b.status === 'Menunggu Konfirmasi' || b.status === 'Terjadwal');
  const historyBookings = myBookings.filter(b => b.status === 'Selesai' || b.status === 'Dibatalkan' || b.status === 'Ditolak');

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', fontFamily: "'Inter', 'Segoe UI', sans-serif", background: '#f0fdf4' }}>
      
      {/* ═══════ HEADER ═══════ */}
      <header style={{
        background: 'linear-gradient(135deg, #166534 0%, #14532d 50%, #052e16 100%)',
        color: 'white',
        padding: '0 24px',
        height: '64px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
        position: 'sticky',
        top: 0,
        zIndex: 50,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{
            width: '42px', height: '42px',
            borderRadius: '12px',
            background: 'white',
            padding: '3px',
            boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
          }}>
            <img src="/logo-smkn1.jpg" alt="Logo" style={{ width: '100%', height: '100%', objectFit: 'contain', borderRadius: '9px' }} />
          </div>
          <div>
            <h1 style={{ fontSize: '16px', fontWeight: 800, letterSpacing: '0.5px', margin: 0, lineHeight: 1.2 }}>
              PORTAL SISWA
            </h1>
            <p style={{ fontSize: '10px', fontWeight: 600, color: '#86efac', letterSpacing: '2px', margin: 0 }}>
              E-KONSELING SMKN 1 PONTIANAK
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ textAlign: 'right' }}>
            <p style={{ fontSize: '13px', fontWeight: 700, margin: 0, lineHeight: 1.2 }}>{namaSiswa}</p>
            <p style={{ fontSize: '10px', fontWeight: 600, color: '#86efac', margin: 0, letterSpacing: '1px' }}>
              KELAS {kelasSiswa.toUpperCase()}
            </p>
          </div>
          <Link href="/" style={{
            padding: '8px 18px',
            borderRadius: '10px',
            fontSize: '11px',
            fontWeight: 700,
            background: 'rgba(255,255,255,0.15)',
            color: 'white',
            textDecoration: 'none',
            border: '1px solid rgba(255,255,255,0.25)',
            transition: 'all 0.2s',
            letterSpacing: '0.5px',
          }}>
            LOGOUT
          </Link>
        </div>
      </header>

      {/* ═══════ BODY LAYOUT ═══════ */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        
        {/* ─── SIDEBAR ─── */}
        <aside style={{
          width: '260px',
          minWidth: '260px',
          background: 'white',
          borderRight: '1px solid #e2e8f0',
          padding: '24px 16px',
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          boxShadow: '2px 0 12px rgba(0,0,0,0.04)',
        }}>
          {/* School Card */}
          <div style={{
            background: 'linear-gradient(135deg, #166534, #15803d)',
            borderRadius: '16px',
            padding: '24px 16px',
            textAlign: 'center',
            marginBottom: '16px',
            boxShadow: '0 4px 16px rgba(22,101,52,0.3)',
          }}>
            <div style={{
              width: '64px', height: '64px',
              borderRadius: '16px',
              background: 'white',
              padding: '4px',
              margin: '0 auto 12px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            }}>
              <img src="/logo-smkn1.jpg" alt="Logo" style={{ width: '100%', height: '100%', objectFit: 'contain', borderRadius: '12px' }} />
            </div>
            <p style={{ color: 'white', fontWeight: 800, fontSize: '13px', margin: 0, letterSpacing: '1px' }}>
              SMK NEGERI 1
            </p>
            <p style={{ color: '#bbf7d0', fontWeight: 600, fontSize: '9px', margin: '4px 0 0', letterSpacing: '3px' }}>
              PUSAT KEUNGGULAN
            </p>
          </div>

          {/* Nav Buttons */}
          {[
            { key: 'dashboard', label: 'Dashboard Utama', icon: '🏠' },
            { key: 'booking', label: 'Booking Konseling', icon: '📅' },
            { key: 'profile', label: 'Pengaturan Profil', icon: '👤' },
          ].map(item => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                padding: '14px 18px',
                borderRadius: '12px',
                border: 'none',
                cursor: 'pointer',
                fontSize: '12px',
                fontWeight: 700,
                letterSpacing: '0.5px',
                transition: 'all 0.2s',
                textAlign: 'left',
                width: '100%',
                ...(activeTab === item.key
                  ? {
                      background: 'linear-gradient(135deg, #166534, #15803d)',
                      color: 'white',
                      boxShadow: '0 4px 12px rgba(22,101,52,0.25)',
                    }
                  : {
                      background: '#f8fafc',
                      color: '#64748b',
                    }
                ),
              }}
            >
              <span style={{ fontSize: '16px' }}>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </aside>

        {/* ─── MAIN CONTENT ─── */}
        <main style={{
          flex: 1,
          padding: '28px 32px',
          overflowY: 'auto',
          minWidth: 0,
        }}>
          <NotificationBanner />
          {activeTab === 'dashboard' ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '28px', maxWidth: '960px' }}>
              {/* ═══ WELCOME HERO ═══ */}
              <div style={{
                background: 'linear-gradient(135deg, #166534 0%, #15803d 100%)',
                borderRadius: '24px',
                padding: '40px',
                color: 'white',
                position: 'relative',
                overflow: 'hidden',
                boxShadow: '0 20px 40px rgba(22,101,52,0.15)',
              }}>
                <div style={{ position: 'relative', zIndex: 1 }}>
                  <h2 style={{ fontSize: '28px', fontWeight: 900, margin: '0 0 8px', letterSpacing: '-0.5px' }}>
                    Halo, {namaSiswa}! 👋
                  </h2>
                  <p style={{ fontSize: '15px', fontWeight: 500, color: '#bbf7d0', maxWidth: '500px', margin: '0 0 24px', lineHeight: 1.6 }}>
                    Selamat datang di Portal Layanan Konseling Digital. Mulailah perubahan positif hari ini dengan berkonsultasi bersama Guru BK ahli kami.
                  </p>
                  <div style={{ display: 'flex', gap: '12px' }}>
                    <button 
                      onClick={() => setActiveTab('booking')}
                      style={{
                        padding: '12px 24px',
                        background: 'white',
                        color: '#166534',
                        border: 'none',
                        borderRadius: '12px',
                        fontSize: '14px',
                        fontWeight: 700,
                        cursor: 'pointer',
                        boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                        transition: 'all 0.2s',
                      }}
                    >
                      Buat Jadwal Baru 📅
                    </button>
                    <button 
                      onClick={() => setActiveTab('booking')}
                      style={{
                        padding: '12px 24px',
                        background: 'rgba(255,255,255,0.15)',
                        color: 'white',
                        border: '1px solid rgba(255,255,255,0.3)',
                        borderRadius: '12px',
                        fontSize: '14px',
                        fontWeight: 700,
                        cursor: 'pointer',
                        transition: 'all 0.2s',
                        backdropFilter: 'blur(4px)',
                      }}
                    >
                      Buka Menu Chat 💬
                    </button>
                  </div>
                </div>
                {/* Decorative Elements */}
                <div style={{ position: 'absolute', top: '-10%', right: '-5%', width: '300px', height: '300px', background: 'rgba(255,255,255,0.05)', borderRadius: '50%' }} />
                <div style={{ position: 'absolute', bottom: '-20%', right: '10%', width: '200px', height: '200px', background: 'rgba(255,255,255,0.1)', borderRadius: '50%' }} />
              </div>

              {/* ═══ STAT CARDS ═══ */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' }}>
                <div style={{ background: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}>
                  <p style={{ color: '#64748b', fontSize: '11px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '1px', margin: '0 0 10px' }}>Konseling Aktif</p>
                  <p style={{ fontSize: '32px', fontWeight: 900, color: '#166534', margin: 0 }}>{activeBookings.length}</p>
                </div>
                <div style={{ background: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}>
                  <p style={{ color: '#64748b', fontSize: '11px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '1px', margin: '0 0 10px' }}>Total Riwayat</p>
                  <p style={{ fontSize: '32px', fontWeight: 900, color: '#1e293b', margin: 0 }}>{historyBookings.length}</p>
                </div>
                <div style={{ background: 'white', padding: '24px', borderRadius: '20px', border: '1px solid #e2e8f0', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}>
                  <p style={{ color: '#64748b', fontSize: '11px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '1px', margin: '0 0 10px' }}>Pesan Baru</p>
                  <p style={{ fontSize: '32px', fontWeight: 900, color: '#dc2626', margin: 0 }}>{Object.values(unreadCounts).reduce((a, b) => a + b, 0)}</p>
                </div>
              </div>

              {/* ═══ RIWAYAT KONSELING ═══ */}
              <section>
                <div style={{
                  background: 'linear-gradient(135deg, #14532d, #166534)',
                  color: 'white',
                  padding: '14px 24px',
                  borderRadius: '12px 12px 0 0',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <span style={{ fontSize: '18px' }}>📋</span>
                    <h3 style={{ fontSize: '13px', fontWeight: 800, letterSpacing: '1.5px', margin: 0, textTransform: 'uppercase' }}>
                      Riwayat Konseling Saya
                    </h3>
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    {['aktif', 'riwayat'].map(tab => (
                      <button
                        key={tab}
                        onClick={() => setHistoryTab(tab)}
                        style={{
                          padding: '6px 14px',
                          borderRadius: '8px',
                          border: 'none',
                          cursor: 'pointer',
                          fontSize: '10px',
                          fontWeight: 700,
                          textTransform: 'uppercase',
                          letterSpacing: '0.5px',
                          transition: 'all 0.2s',
                          ...(historyTab === tab
                            ? { background: 'white', color: '#1e293b' }
                            : { background: 'rgba(255,255,255,0.15)', color: 'rgba(255,255,255,0.7)' }
                          ),
                        }}
                      >
                        {tab === 'aktif' ? 'Aktif' : 'Riwayat'}
                        {tab === 'aktif' && activeBookings.length > 0 && (
                          <span style={{
                            marginLeft: '6px',
                            background: '#dc2626',
                            color: 'white',
                            borderRadius: '999px',
                            padding: '1px 6px',
                            fontSize: '9px',
                          }}>
                            {activeBookings.length}
                          </span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div style={{
                  background: 'white',
                  border: '1px solid #e2e8f0',
                  borderTop: 'none',
                  borderRadius: '0 0 12px 12px',
                  overflow: 'hidden',
                }}>
                  {/* Table */}
                  <div style={{ overflowX: 'auto' }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                      <thead>
                        <tr>
                          {['Guru Pembimbing', 'Waktu Pertemuan', 'Perihal Masalah', 'Status', 'Aksi'].map((th, i) => (
                            <th key={th} style={{
                              background: '#f8fafc',
                              color: '#64748b',
                              fontWeight: 800,
                              fontSize: '11px',
                              textAlign: i === 3 ? 'center' : i === 4 ? 'right' : 'left',
                              padding: '16px 24px',
                              letterSpacing: '0.5px',
                              textTransform: 'uppercase',
                              borderBottom: '1px solid #e2e8f0',
                            }}>
                              {th}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {(() => {
                          const filtered = historyTab === 'aktif' ? activeBookings : historyBookings;
                          if (filtered.length === 0) return (
                            <tr>
                              <td colSpan="5" style={{ padding: '60px 24px', textAlign: 'center', color: '#94a3b8', fontWeight: 500, fontStyle: 'italic', fontSize: '14px' }}>
                                {historyTab === 'aktif' ? 'Tidak ada konseling yang sedang aktif.' : 'Belum ada riwayat konseling yang selesai.'}
                              </td>
                            </tr>
                          );
                          return filtered.map(b => (
                            <tr key={b.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                              <td style={{ padding: '18px 24px', fontWeight: 700, fontSize: '13px', color: '#1e293b' }}>{b.guruName}</td>
                              <td style={{ padding: '18px 24px', fontWeight: 500, fontSize: '13px', color: '#64748b' }}>{b.date} • {b.time}</td>
                              <td style={{ padding: '18px 24px', fontWeight: 400, fontSize: '13px', color: '#94a3b8', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.kebutuhan}</td>
                              <td style={{ padding: '18px 24px', textAlign: 'center' }}>
                                <span style={{
                                  padding: '6px 14px',
                                  borderRadius: '20px',
                                  fontSize: '10px',
                                  fontWeight: 800,
                                  ...(b.status === 'Terjadwal' ? { background: '#f0fdf4', color: '#166534', border: '1px solid #bbf7d0' } :
                                     b.status === 'Selesai' ? { background: '#dcfce7', color: '#15803d', border: '1px solid #bbf7d0' } :
                                     b.status === 'Menunggu Konfirmasi' ? { background: '#fffbeb', color: '#b45309', border: '1px solid #fde68a' } :
                                     { background: '#fef2f2', color: '#dc2626', border: '1px solid #fecaca' }
                                  )
                                }}>
                                  {b.status.toUpperCase()}
                                </span>
                              </td>
                              <td style={{ padding: '18px 24px', textAlign: 'right' }}>
                                {b.status === 'Menunggu Konfirmasi' && (
                                  <button
                                    onClick={() => handleCancelBooking(b.id)}
                                    style={{
                                      background: '#fef2f2',
                                      border: '1px solid #fecaca',
                                      color: '#dc2626',
                                      padding: '8px 16px',
                                      borderRadius: '8px',
                                      fontSize: '10px',
                                      fontWeight: 800,
                                      cursor: 'pointer',
                                      textTransform: 'uppercase',
                                      transition: 'all 0.2s',
                                    }}
                                  >
                                    BATALKAN
                                  </button>
                                )}
                              </td>
                            </tr>
                          ));
                        })()}
                      </tbody>
                    </table>
                  </div>
                </div>
              </section>
            </div>
          ) : activeTab === 'booking' ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', maxWidth: '1000px' }}>
              <div style={{ marginBottom: '8px' }}>
                <h2 style={{ fontSize: '24px', fontWeight: 900, color: '#1e293b', margin: '0 0 4px' }}>Sistem Booking Konseling</h2>
                <p style={{ color: '#64748b', fontSize: '14px', fontWeight: 500 }}>Silakan pilih Guru BK yang tersedia untuk melakukan pendaftaran bimbingan.</p>
              </div>

              {/* Search & Filter */}
              <div style={{ display: 'flex', gap: '12px', background: 'white', padding: '16px', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
                <div style={{ flex: 1, position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '16px', top: '50%', transform: 'translateY(-50%)', opacity: 0.5 }}>🔍</span>
                  <input 
                    type="text" 
                    placeholder="Cari Nama Guru BK..." 
                    value={searchGuru}
                    onChange={(e) => setSearchGuru(e.target.value)}
                    style={{ width: '100%', padding: '12px 12px 12px 48px', borderRadius: '12px', border: '1px solid #e2e8f0', fontSize: '14px', fontWeight: 500 }}
                  />
                </div>
              </div>

              {/* ═══ DAFTAR GURU BK ═══ */}
              <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
                gap: '20px',
              }}>
                {schedules.filter(s => s.name.toLowerCase().includes(searchGuru.toLowerCase())).map(s => (
                  <div key={s.id} style={{
                    background: 'white',
                    border: '1px solid #e2e8f0',
                    borderRadius: '20px',
                    padding: '24px',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: '20px',
                    transition: 'all 0.3s ease',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.02)',
                    position: 'relative',
                  }}>
                    {/* Badge Status */}
                    <div style={{
                      position: 'absolute',
                      top: '20px',
                      right: '20px',
                    }}>
                      <span style={{
                        fontSize: '9px',
                        fontWeight: 800,
                        padding: '4px 10px',
                        borderRadius: '20px',
                        textTransform: 'uppercase',
                        letterSpacing: '0.8px',
                        ...(s.status === 'Tersedia'
                          ? { background: '#dcfce7', color: '#166534', border: '1px solid #bbf7d0' }
                          : { background: '#fef2f2', color: '#dc2626', border: '1px solid #fecaca' }
                        )
                      }}>
                        {s.status}
                      </span>
                    </div>

                    <div style={{ display: 'flex', alignItems: 'center', gap: '18px' }}>
                      <div style={{
                        width: '64px', height: '64px',
                        background: 'linear-gradient(135deg, #166534, #15803d)',
                        borderRadius: '18px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontWeight: 800,
                        fontSize: '24px',
                        color: 'white',
                        boxShadow: '0 8px 16px rgba(22,101,52,0.2)',
                      }}>
                        {s.name.charAt(0)}
                      </div>
                      <div style={{ flex: 1 }}>
                        <h4 style={{ fontSize: '16px', fontWeight: 800, color: '#1e293b', margin: '0 0 4px', lineHeight: 1.2 }}>
                          {s.name}
                        </h4>
                        <p style={{ fontSize: '11px', fontWeight: 700, color: '#64748b', margin: 0, textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                          {s.specialty}
                        </p>
                      </div>
                    </div>

                    <div style={{ borderTop: '1px solid #f1f5f9', paddingTop: '16px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '13px', color: '#64748b', fontWeight: 500 }}>
                        <span>📅</span> {s.date}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', fontSize: '13px', color: '#64748b', fontWeight: 500 }}>
                        <span>🕒</span> {s.time}
                      </div>
                    </div>

                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 3fr', gap: '10px' }}>
                      <Link
                        href={`/chat?targetId=${s.guruId}&targetName=${encodeURIComponent(s.name)}&targetRole=guru`}
                        style={{
                          background: '#f8fafc',
                          border: '1px solid #e2e8f0',
                          borderRadius: '12px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          textDecoration: 'none',
                          fontSize: '18px',
                          transition: 'all 0.2s',
                          position: 'relative',
                        }}
                      >
                        💬
                        {unreadCounts[s.guruId] > 0 && (
                          <span style={{
                            position: 'absolute',
                            top: '-6px',
                            right: '-6px',
                            background: '#ef4444',
                            color: 'white',
                            fontSize: '10px',
                            fontWeight: 800,
                            padding: '2px 6px',
                            borderRadius: '10px',
                            border: '2px solid white'
                          }}>
                            {unreadCounts[s.guruId]}
                          </span>
                        )}
                      </Link>
                      <button
                        onClick={() => setSelectedSchedule(s)}
                        disabled={s.status !== 'Tersedia'}
                        style={{
                          padding: '14px',
                          borderRadius: '12px',
                          border: 'none',
                          cursor: s.status === 'Tersedia' ? 'pointer' : 'not-allowed',
                          fontSize: '12px',
                          fontWeight: 800,
                          textTransform: 'uppercase',
                          letterSpacing: '1px',
                          transition: 'all 0.3s ease',
                          ...(s.status === 'Tersedia'
                            ? { background: 'linear-gradient(135deg, #166534, #15803d)', color: 'white', boxShadow: '0 4px 12px rgba(22,101,52,0.3)' }
                            : { background: '#e2e8f0', color: '#94a3b8' }
                          ),
                        }}
                      >
                        BOOKING SEKARANG
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* ═══ PROFILE TAB ═══ */
            <div style={{
              background: 'white',
              border: '1px solid #e2e8f0',
              borderRadius: '16px',
              padding: '32px',
              maxWidth: '800px',
              boxShadow: '0 4px 16px rgba(0,0,0,0.04)',
            }}>
              <h4 style={{
                fontSize: '16px',
                fontWeight: 800,
                color: '#1e293b',
                textTransform: 'uppercase',
                letterSpacing: '1.5px',
                paddingBottom: '16px',
                borderBottom: '2px solid #f1f5f9',
                margin: '0 0 28px',
              }}>
                Pengaturan Profil Pengguna
              </h4>

              <div style={{ display: 'flex', gap: '40px' }}>
                {/* Photo Section */}
                <div style={{ textAlign: 'center', minWidth: '160px' }}>
                  <div style={{
                    width: '140px', height: '140px',
                    background: '#f8fafc',
                    border: '2px solid #e2e8f0',
                    borderRadius: '16px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    overflow: 'hidden',
                    margin: '0 auto 16px',
                  }}>
                    {profileData.previewUrl
                      ? <img src={profileData.previewUrl} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                      : <span style={{ fontSize: '48px', fontWeight: 800, color: '#cbd5e1' }}>{namaSiswa.charAt(0)}</span>
                    }
                  </div>
                  <label style={{
                    display: 'inline-block',
                    padding: '10px 20px',
                    background: '#1e293b',
                    color: 'white',
                    borderRadius: '10px',
                    fontSize: '10px',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '0.5px',
                    cursor: 'pointer',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
                  }}>
                    GANTI FOTO
                    <input type="file" style={{ display: 'none' }} accept="image/*" onChange={e => {
                      const f = e.target.files[0];
                      if (f) setProfileData({ ...profileData, photo: f, previewUrl: URL.createObjectURL(f) });
                    }} />
                  </label>
                </div>

                {/* Form Section */}
                <div style={{ flex: 1 }}>
                  <form onSubmit={handleUpdateProfile} style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                      <div>
                        <label style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' }}>Nama Siswa</label>
                        <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '12px 14px', fontSize: '13px', fontWeight: 600, color: '#94a3b8' }}>{namaSiswa}</div>
                      </div>
                      <div>
                        <label style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' }}>Kelas</label>
                        <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: '8px', padding: '12px 14px', fontSize: '13px', fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase' }}>{kelasSiswa}</div>
                      </div>
                    </div>

                    <div>
                      <label style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' }}>Keterangan Hobi / Minat</label>
                      <input
                        value={profileData.hobi}
                        onChange={e => setProfileData({ ...profileData, hobi: e.target.value })}
                        type="text"
                        placeholder="Isi sesuai minat Anda..."
                        style={{ fontSize: '13px', fontWeight: 500 }}
                      />
                    </div>

                    <div>
                      <label style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' }}>Visi & Rencana Masa Depan</label>
                      <textarea
                        value={profileData.rencana_masa_depan}
                        onChange={e => setProfileData({ ...profileData, rencana_masa_depan: e.target.value })}
                        placeholder="Paparkan rencana pendidikan atau karir Anda..."
                        style={{ fontSize: '13px', fontWeight: 500, height: '120px', resize: 'none' }}
                      />
                    </div>

                    <button
                      disabled={isUpdatingProfile}
                      type="submit"
                      style={{
                        padding: '14px 32px',
                        background: 'linear-gradient(135deg, #166534, #15803d)',
                        color: 'white',
                        border: 'none',
                        borderRadius: '10px',
                        fontSize: '12px',
                        fontWeight: 700,
                        textTransform: 'uppercase',
                        letterSpacing: '1px',
                        cursor: isUpdatingProfile ? 'not-allowed' : 'pointer',
                        boxShadow: '0 4px 12px rgba(22,101,52,0.25)',
                        opacity: isUpdatingProfile ? 0.6 : 1,
                        alignSelf: 'flex-start',
                      }}
                    >
                      {isUpdatingProfile ? "SEDANG MENYIMPAN..." : "SIMPAN PERUBAHAN DATA"}
                    </button>
                  </form>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* ═══════ BOOKING FORM MODAL ═══════ */}
      {selectedSchedule && (
        <div style={{
          position: 'fixed',
          inset: 0,
          zIndex: 100,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '24px',
          background: 'rgba(15, 23, 42, 0.6)',
          backdropFilter: 'blur(4px)',
        }}>
          <div style={{
            background: 'white',
            border: '2px solid #166534',
            width: '100%',
            maxWidth: '520px',
            borderRadius: '16px',
            overflow: 'hidden',
            boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
          }}>
            {/* Modal Header */}
            <div style={{
              background: 'linear-gradient(135deg, #166534, #15803d)',
              color: 'white',
              padding: '18px 28px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
              <h3 style={{ fontWeight: 800, fontSize: '13px', letterSpacing: '1.5px', margin: 0, textTransform: 'uppercase' }}>
                Formulir Pengajuan Bimbingan
              </h3>
              <button
                onClick={() => setSelectedSchedule(null)}
                style={{
                  background: 'rgba(255,255,255,0.2)',
                  border: 'none',
                  color: 'white',
                  fontWeight: 700,
                  fontSize: '12px',
                  cursor: 'pointer',
                  padding: '6px 14px',
                  borderRadius: '8px',
                }}
              >
                ✕ TUTUP
              </button>
            </div>

            {isSuccess ? (
              <div style={{ padding: '60px 32px', textAlign: 'center' }}>
                <div style={{
                  width: '64px', height: '64px',
                  background: '#dcfce7',
                  borderRadius: '999px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 16px',
                  border: '2px solid #bbf7d0',
                  fontSize: '28px',
                }}>
                  ✓
                </div>
                <h2 style={{ fontSize: '18px', fontWeight: 800, color: '#1e293b', margin: '0 0 8px' }}>DATA BERHASIL DIKIRIM</h2>
                <p style={{ fontSize: '13px', color: '#64748b', fontWeight: 500, margin: 0 }}>
                  Silakan pantau status pendaftaran pada tabel riwayat dashboard Anda.
                </p>
              </div>
            ) : (
              <form onSubmit={handleDaftar} style={{ padding: '28px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
                {/* Target Guru */}
                <div style={{
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '10px',
                  padding: '14px 18px',
                }}>
                  <p style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', margin: '0 0 4px' }}>Target Pembimbing:</p>
                  <p style={{ fontSize: '16px', fontWeight: 800, color: '#166534', margin: 0, textTransform: 'uppercase' }}>{selectedSchedule.name}</p>
                </div>

                {/* Date & Time */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
                  <div>
                    <label style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' }}>Pilih Tanggal</label>
                      <input 
                        value={selectedDate} 
                        onChange={e => setSelectedDate(e.target.value)} 
                        type="date" 
                        min={new Date().toISOString().split('T')[0]}
                        style={{ fontSize: '13px', fontWeight: 600 }} 
                        required 
                      />
                  </div>
                  <div>
                    <label style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' }}>Pukul Sesi</label>
                    <select value={selectedTime} onChange={e => setSelectedTime(e.target.value)} style={{ fontSize: '13px', fontWeight: 600 }} required>
                      <option value="">-- Pilih Jam --</option>
                      {['08:00','08:30','09:00','09:30','10:00','10:30','11:00','11:30','12:00','12:30'].map(t => (
                        <option key={t} value={t}>{t} WIB</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Kategori */}
                <div>
                  <label style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' }}>Kategori Bimbingan</label>
                  <select value={kategori} onChange={e => setKategori(e.target.value)} style={{ fontSize: '13px', fontWeight: 600 }} required>
                    <option value="">-- Pilih Jenis Bimbingan --</option>
                    <option value="Akademik">Bimbingan Belajar / Akademik</option>
                    <option value="Karir">Bimbingan Karir & Studi Lanjut</option>
                    <option value="Sosial">Permasalahan Sosial & Teman</option>
                    <option value="Pribadi">Kesejahteraan / Permasalahan Pribadi</option>
                    <option value="Lainnya">Lain-lain</option>
                  </select>
                </div>

                {/* Ringkasan */}
                <div>
                  <label style={{ fontSize: '10px', fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', display: 'block', marginBottom: '6px' }}>Ringkasan Persoalan</label>
                  <textarea
                    value={kebutuhan}
                    onChange={e => setKebutuhan(e.target.value)}
                    placeholder="Tuliskan alasan mengapa Anda ingin bimbingan..."
                    style={{ fontSize: '13px', fontWeight: 500, height: '100px', resize: 'none' }}
                    required
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={isSubmitting}
                  style={{
                    padding: '16px',
                    background: isSubmitting ? '#94a3b8' : 'linear-gradient(135deg, #166534, #15803d)',
                    color: 'white',
                    border: 'none',
                    borderRadius: '10px',
                    fontSize: '12px',
                    fontWeight: 700,
                    textTransform: 'uppercase',
                    letterSpacing: '1.5px',
                    cursor: isSubmitting ? 'not-allowed' : 'pointer',
                    boxShadow: isSubmitting ? 'none' : '0 4px 16px rgba(22,101,52,0.3)',
                    transition: 'all 0.3s ease',
                  }}
                >
                  {isSubmitting ? 'SEDANG MENGIRIM...' : 'KIRIM PENGAJUAN BIMBINGAN'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function SiswaDashboard() {
  return (
    <Suspense fallback={<div style={{ minHeight: '100vh', background: '#f0fdf4', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700 }}>Memuat...</div>}>
      <SiswaDashboardContent />
    </Suspense>
  );
}
