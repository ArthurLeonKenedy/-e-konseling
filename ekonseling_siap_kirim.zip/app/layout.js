import { Inter, Outfit } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

const outfit = Outfit({
  subsets: ["latin"],
  variable: "--font-outfit",
});

export const metadata = {
  title: "E-Konseling - Platform Bimbingan Terpercaya",
  description: "Layanan bimbingan konseling digital yang aman, nyaman, dan profesional.",
};

export default function RootLayout({ children }) {
  return (
      <html
      lang="id"
      className={`${inter.variable} ${outfit.variable} h-full antialiased selection:bg-emerald-500/30 font-sans`}
    >
      <body className="min-h-full flex flex-col bg-white font-sans text-slate-900">{children}</body>
    </html>
  );
}
